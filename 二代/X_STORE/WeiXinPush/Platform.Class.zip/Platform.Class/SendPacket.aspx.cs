﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using Homory.Model;

public partial class SendPacket : BasePage
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageInit();

        }
    }


    protected void PageInit() {

        clear(); 

        var classId = Guid.Parse(Session["class_id"].ToString());

        var partS = new Object();

        if (GetAuth() == 2)
        {
            partS = db.View_TeacherInClass.Where(o => o.DepartmentId == classId).Select(o => new { Id = o.UserId, Name = o.DisplayName, @Type = true }).ToList();
        }
        else
        {
            partS = db.DepartmentUser.Where(o => o.Type == DepartmentUserType.班级学生 && o.State == State.启用 && o.DepartmentId == classId).ToList().Select(o => new { Id = o.UserId, Name = o.User.RealName, @Type = true }).ToList();
        }
      
        student_packet_RLB.DataSource = partS;

        student_packet_RLB.DataBind();
    }

    protected void send_packet_RB_Click(object sender, EventArgs e)
    {
        
        ChatHub ch = new ChatHub();

        RadListBoxItemCollection packets = this.selected_packet_RLB.Items;

        var message = this.pocket_message_ta.Text;

        string userList = string.Empty;

        var time1 = Convert.ToDateTime(DateTime.Now.AddSeconds(-30).ToString("yyyy/MM/dd HH:mm:ss"));

        var call = db.C_call.Where(o => o.Datetime > time1 && o.Message == message).ToList();

        if (call.Count > 0)
        {
            packet_P.ResponseScripts.Add("Alert('请勿重复提交！')");

            return;
        }

        Guid GroupKey = Guid.NewGuid();

        foreach (RadListBoxItem item in packets)
	    { 

            C_call cc = new C_call();

            Guid id = Guid.NewGuid();

            cc.Id = id;

            cc.Message = message;

            cc.UserId = UserId;

            cc.ReceiverID = Guid.Parse(item.Value);

            userList += item.Value + "|"; 

            cc.Datetime = DateTime.Now;

            cc.TopId = id;

            cc.State = State.启用;

            cc.GroupKey = GroupKey;

            db.C_call.Add(cc);

	    }

        var OpenIdListStr = string.Empty;

        var UserNameListStr = string.Empty;

        findOpenIdByUserId(userList, out OpenIdListStr, out UserNameListStr);

        var FinalOpenIdList = OpenIdListStr.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

        var FinalUserNameListStr = UserNameListStr.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

        for (int i = 0; i < FinalOpenIdList.Length; i++)
        {

            var userPush = new UserPush();

            userPush.Id = Guid.NewGuid();

            userPush.MessageId = GroupKey;

            userPush.OpenId = FinalOpenIdList[i].ToString();

            userPush.Push = false;

            userPush.Type = PushType.班级寻呼;
           
            userPush.UserId = Guid.Parse(this.Session["user_id"].ToString());

            db.UserPush.Add(userPush);
          
        }

        db.SaveChanges();
      
        packet_P.ResponseScripts.Add("Refresh('"+ userList + "')");

        PageInit();

        
    }

    protected void findOpenIdByUserId(string UserIdListStr, out string OpenIdListFinalStr, out string UserNameListFinalStr)
    {
        var UserIdList = UserIdListStr.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

        var OpenIdListStr = string.Empty;

        var UserNameListStr = string.Empty;

        foreach (var UserItem in UserIdList)
        {
            var UserId = Guid.Parse(UserItem);

            var OpenIdList = db.UserOpen.Where(o => o.UserId == UserId).ToList();

            foreach (var OpenItem in OpenIdList)
            {
                OpenIdListStr += OpenItem.OpenId.ToString() + "|";

                UserNameListStr += db.User.SingleOrDefault(o => o.Id == OpenItem.UserId).DisplayName.ToString() + "|";
            }
        }
        OpenIdListFinalStr = OpenIdListStr;

        UserNameListFinalStr = UserNameListStr;
    
    }

    protected void clear_packet_RB_Click(object sender, EventArgs e)
    {
        PageInit();
    }

    protected void clear() {

        this.pocket_message_ta.Text = string.Empty;

        this.selected_packet_RLB.Items.Clear();
    }

}
