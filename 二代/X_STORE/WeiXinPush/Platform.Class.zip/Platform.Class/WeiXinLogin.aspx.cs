﻿using Homory.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Entity.Migrations;


public partial class WeiXinLogin : BasePage
{

    protected void Page_Load(object sender, EventArgs e)
    {
    
    }

    protected void submit_Click(object sender, EventArgs e)
    {
        var OpenID = Session["GlobalOpenId"].ToString();

        var UserName = this.username.Text;

        string key; 

        string salt;

        var Password = HomoryCryptor.Encrypt(this.password.Text.ToLower(), out key, out salt);

        var userName = this.username.Text.ToLower();

        var user = db.User.SingleOrDefault(o => o.Account == userName && o.Password == Password && o.State < State.审核);

		if (user == null)
		{
			Response.Write("<script>alert('请输入正确的账号和密码')</script>");
			return ;
		}
        else
	    {
            UserOpen userOpen = new UserOpen();

            userOpen.UserId = user.Id;

            userOpen.Provider = "微信";

            userOpen.OpenId = OpenID;

            userOpen.DateTime = DateTime.Now;

            if (db.UserOpen.Count(o=>o.UserId == userOpen.UserId && o.OpenId == userOpen.OpenId && o.Provider == userOpen.Provider) > 0)
            {
                return;
            }

            db.UserOpen.Add(userOpen);

            db.SaveChanges();

            this.Session["user_id"] = user.Id;

            var RedirectUrl = weixin_url + "Home.aspx";

            Response.Redirect(RedirectUrl);
	    }   
    }
}