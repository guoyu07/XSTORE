﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Main_left_menu : BaseControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            LM_PageInit();
        }

    }

    protected void LM_PageInit()
    { 
    
        switch (GetAuth())
	    {
                case 1:
                this.table_manager_li.Visible = false;
                this.class_manager_li.Visible = false;
                break;
                case 2:
                this.study_helper_li.Visible = false;
                this.table_manager_li.Visible = false;
                this.class_manager_li.Visible = false;
                //this.send_packet_li.Visible = false;
                break;
                case 5:
                this.study_helper_li.Visible = false;
                //this.table_manager_li.Visible = false;
                //this.send_packet_li.Visible = false;
                break;
		    default:break;
	    }
  
    }

    protected string findUrl() {

        try
        {

            string boot_url = GetResourceUrl("ResourceUrl");

            string user_id = this.Session["user_id"].ToString();

            string course_id = this.Session["course_id"].ToString();

            string grade_id = this.Session["grade_id"].ToString();
            //GadeId：int32 对应 Catalog表State=1，Type=1的Ordinal=GradeId
            string final_url = boot_url + "/PublishingClass.aspx?UserId=" + user_id + "&CourseId=" + course_id + "&GradeId=" + grade_id + "";

            return final_url;
        }
        catch
        {
            return "";
        }

    }

}