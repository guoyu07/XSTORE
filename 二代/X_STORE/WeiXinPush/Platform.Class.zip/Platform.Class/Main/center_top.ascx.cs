﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Homory.Model;

public partial class Main_center_top : BaseControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            CT_PageInit();

            
        }
       


    }
    protected void CT_PageInit()
    {

        var cid = Guid.Parse(this.Session["class_id"].ToString());

        var topId = pe.Department.First(o => o.Id == cid).TopId;
        
        var title_name = pe.Department.First(o => o.Id == topId).Name;

        this.title_head_label.Text = "我的班级:";

        this.title_label.Text = title_name + this.Session["class_name"].ToString();

        var csc = pe.C_site_config.SingleOrDefault(o => o.ClassId == cid);

        DataTable dt = new DataTable();

        DataColumn url_dc = new DataColumn("Url", typeof(string));

        DataColumn img_dc = new DataColumn("imgClass", typeof(string));

        dt.Columns.Add(url_dc);

        dt.Columns.Add(img_dc);

        if (csc != null)
        {

            var url_list = csc.Url.Equals(string.Empty) ? new List<string>() : csc.Url.Split('|').ToList();

            for (int i = 0; i < url_list.Count(); i++)
            {
                DataRow dr = dt.NewRow();

                dr["imgClass"] = i == 0 ? "item active" : "item";

                dr["Url"] = url_list[i];

                dt.Rows.Add(dr);
            }
        }

        this.class_picture_R.DataSource = dt;

        this.class_picture_R.DataBind();
    
    }
   
    protected string GetTearchSaying() {
        try
        {
            var cid = Guid.Parse(this.Session["class_id"].ToString());

            var csc = pe.C_site_config.SingleOrDefault(o => o.ClassId == cid);

            return csc.Message == null ? string.Empty : csc.Message;
        }
        catch { return ""; }
    }

}