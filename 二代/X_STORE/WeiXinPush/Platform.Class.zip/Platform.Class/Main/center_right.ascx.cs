﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;

public partial class Main_center_right : BaseControl
{
    protected static Weather w = new Weather();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            w = GetWeather();

            bool hout = DateTime.Now.Hour < 17;
        }
    }

    protected string GetQQ(){
        try
        {
            var cid = Guid.Parse(this.Session["class_id"].ToString());

            var csc = pe.C_site_config.SingleOrDefault(o => o.ClassId == cid);

            return csc.QQ == null ? "" : csc.QQ;
        }
        catch
        { return ""; }
    
    }
    protected string GetWeiXin() {
        try
        {
            var cid = Guid.Parse(this.Session["class_id"].ToString());

            var csc = pe.C_site_config.SingleOrDefault(o => o.ClassId == cid);

            return csc.Wximg == null ? "" : csc.Wximg;
        }
        catch
        { return ""; }
    }
    protected static Weather GetWeather()
    {
        

        Weather w = new Weather();

       
        try
        {
            Encoding encoding = Encoding.GetEncoding("utf-8");

            string url = string.Format("http://php.weather.sina.com.cn/xml.php?city={0}&password=DJOYnieT8234jlsK&day=0&qq-pf-to=pcqq.c2c", X(Encoding.Default.GetBytes("无锡")));

            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);

            request.Timeout = 1000;

            request.Method = "GET";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            StreamReader sr = new StreamReader(response.GetResponseStream(), encoding);

            string xmlStr = sr.ReadToEnd();

            var doc = XDocument.Parse(xmlStr);

            var weather = doc.Root.Element("Weather");
            if (weather == null)
            {
                w.temp1 = "无数据";

                w.night_temp1 = "无数据";

                w.figure1 = "无数据";

                w.night_figure1 = "无数据";

                w.week1 = DateTime.Today.AddDays(+0).DayOfWeek.ToString().Substring(0, 3).ToUpper();
            }
            else
            {
                w.city = weather.Element("city").Value;

                w.temp1 = weather.Element("temperature1").Value;

                w.night_temp1 = weather.Element("temperature2").Value;

                w.figure1 = findWeatherPictrue(weather.Element("figure1").Value);

                w.night_figure1 = findWeatherPictrue(weather.Element("figure2").Value);

                w.week1 = DateTime.Today.DayOfWeek.ToString().Substring(0, 3).ToUpper();

                //XElement root2 = xml_root.Element("Weather");

                //XElement template = root2.Element("temperature1");

                //string str_root = template.Value;
            }
            
            sr.Close();

            url = string.Format("http://php.weather.sina.com.cn/xml.php?city={0}&password=DJOYnieT8234jlsK&day=1&qq-pf-to=pcqq.c2c", X(Encoding.Default.GetBytes("无锡")));

            request = (HttpWebRequest)HttpWebRequest.Create(url);

            request.Timeout = 1000;

            request.Method = "GET";

            response = (HttpWebResponse)request.GetResponse();

            sr = new StreamReader(response.GetResponseStream(), encoding);

            xmlStr = sr.ReadToEnd();

            doc = XDocument.Parse(xmlStr);

            weather = doc.Root.Element("Weather");

            if (weather == null)
            {
                w.temp2 = "无数据";

                w.night_temp2 = "无数据";

                w.figure2 = "无数据";

                w.night_figure2 = "无数据";

                w.week2 = DateTime.Today.AddDays(+1).DayOfWeek.ToString().Substring(0, 3).ToUpper();
            }
            else
            {
                w.temp2 = weather.Element("temperature1").Value;

                w.night_temp2 = weather.Element("temperature2").Value;

                w.figure2 = findWeatherPictrue(weather.Element("figure1").Value);

                w.night_figure2 = findWeatherPictrue(weather.Element("figure2").Value);

                w.week2 = DateTime.Today.AddDays(+1).DayOfWeek.ToString().Substring(0, 3).ToUpper();
            }

            sr.Close();

            url = string.Format("http://php.weather.sina.com.cn/xml.php?city={0}&password=DJOYnieT8234jlsK&day=2&qq-pf-to=pcqq.c2c", X(Encoding.Default.GetBytes("无锡")));

            request = (HttpWebRequest)HttpWebRequest.Create(url);

            request.Timeout = 1000;

            request.Method = "GET";

            response = (HttpWebResponse)request.GetResponse();

            sr = new StreamReader(response.GetResponseStream(), encoding);

            xmlStr = sr.ReadToEnd();

            doc = XDocument.Parse(xmlStr);

            weather = doc.Root.Element("Weather");
            if (weather == null)
            {
                w.temp3 = "无数据";

                w.night_temp3 = "无数据";

                w.figure3 = "无数据";

                w.night_figure3 = "无数据";

                w.week3 = DateTime.Today.AddDays(+2).DayOfWeek.ToString().Substring(0, 3).ToUpper();
            }
            else
            {
                w.temp3 = weather.Element("temperature1").Value;

                w.night_temp3 = weather.Element("temperature2").Value;

                w.figure3 = findWeatherPictrue(weather.Element("figure1").Value);

                w.night_figure3 = findWeatherPictrue(weather.Element("figure2").Value);

                w.week3 = DateTime.Today.AddDays(+2).DayOfWeek.ToString().Substring(0, 3).ToUpper(); 
            }

            sr.Close();

            url = string.Format("http://php.weather.sina.com.cn/xml.php?city={0}&password=DJOYnieT8234jlsK&day=3&qq-pf-to=pcqq.c2c", X(Encoding.Default.GetBytes("无锡")));

            request = (HttpWebRequest)HttpWebRequest.Create(url);

            request.Timeout = 1000;

            request.Method = "GET";

            response = (HttpWebResponse)request.GetResponse();

            sr = new StreamReader(response.GetResponseStream(), encoding);

            xmlStr = sr.ReadToEnd();

            doc = XDocument.Parse(xmlStr);

            weather = doc.Root.Element("Weather");
            if (weather == null)
            {
                w.temp4 = "无数据";

                w.night_temp4 = "无数据";

                w.figure4 = "无数据";

                w.night_figure4 = "无数据";

                w.week4 = DateTime.Today.AddDays(+3).DayOfWeek.ToString().Substring(0, 3).ToUpper();
            }
            else
            {
                w.temp4 = weather.Element("temperature1").Value;

                w.night_temp4 = weather.Element("temperature2").Value;

                w.figure4 = findWeatherPictrue(weather.Element("figure1").Value);

                w.night_figure4 = findWeatherPictrue(weather.Element("figure2").Value);

                w.week4 = DateTime.Today.AddDays(+3).DayOfWeek.ToString().Substring(0, 3).ToUpper();
            }


            sr.Close();
        }
        catch (Exception)
        {

            w.temp1 = "无数据";

            w.night_temp1 = "无数据";

            w.figure1 = "无数据";

            w.night_figure1 = "无数据";

            w.week1 = DateTime.Today.AddDays(+0).DayOfWeek.ToString().Substring(0, 3).ToUpper();

            w.temp2 = "无数据";

            w.night_temp2 = "无数据";

            w.figure2 = "无数据";

            w.night_figure2 = "无数据";

            w.week2 = DateTime.Today.AddDays(+1).DayOfWeek.ToString().Substring(0, 3).ToUpper();

            w.temp3 = "无数据";

            w.night_temp3 = "无数据";

            w.figure3 = "无数据";

            w.night_figure3 = "无数据";

            w.week3 = DateTime.Today.AddDays(+2).DayOfWeek.ToString().Substring(0, 3).ToUpper();

            w.temp4 = "无数据";

            w.night_temp4 = "无数据";

            w.figure4 = "无数据";

            w.night_figure4 = "无数据";

            w.week4 = DateTime.Today.AddDays(+3).DayOfWeek.ToString().Substring(0, 3).ToUpper();
        }

        return w;

    }

    protected static string findWeatherPictrue(string str){

        switch (str)
        {
            case "duoyun": return "partly-cloudy-day";
            case "qing": return "clear-day";
            case "xiaoyu": return "rain";
            case "yin": return "cloudy";
            default: return "clear-day";
        }
        
    }

    //protected string findWeekToday()
    //{
    //    //DayOfWeek week = DateTime.Today.DayOfWeek;
    //    //week.ToString();
    //    //switch (week)
    //    //{
    //    //    case "duoyun": return "cloudy";
    //    //    case "qing": return "clear";
    //    //    default: return "clear";
    //    //}

    //}
    protected static string X(byte[] bs)
    {
        var sb = new StringBuilder();
        foreach (byte b in bs)
        {
            sb.Append("%" + b.ToString("X2"));
        }
        return sb.ToString();
    }
    
}