﻿using Homory.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using System.Data.Entity;

public partial class Main_top_menu : BaseControl
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            var b = ShowSearchBox;
          
            TM_PageInit();
            
            lblCount.Text = GetPacketCount().ToString();

            switch (GetAuth())
            {
                case 0:
                case 1:
                case 5:
                    if (c_teacher_RDD.Items.Count > 0)
                    {
                        c_teacher_RDD.SelectedIndex = Session["class_id"] == null ? 0 : c_teacher_RDD.Items.First(o => o.Value.IndexOf(Session["class_id"].ToString()) == 0).Index;
                        Session["class_id"] = c_teacher_RDD.SelectedItem.Value.Substring(0, c_teacher_RDD.SelectedItem.Value.IndexOf('|'));

                        Session["grade_id"] = SetGradeSession(Guid.Parse(Session["class_id"].ToString()));

                        Session["class_name"] = c_teacher_RDD.SelectedItem.Text;

                        Session["course_id"] = c_teacher_RDD.SelectedItem.Value.Split('|')[1].ToString();
                    }

                    create_class_site(Session["class_id"].ToString());
                    break;
                case 2:
                
                    if (c_teacher_RDD.Items.Count > 0)
                    {
                        c_teacher_RDD.SelectedIndex = Session["class_id"] == null ? 0 : c_teacher_RDD.Items.First(o => o.Value.IndexOf(Session["class_id"].ToString()) == 0).Index;
                        
                        Session["class_id"] = c_teacher_RDD.SelectedItem.Value;

                        Session["grade_id"] = SetGradeSession(Guid.Parse(Session["class_id"].ToString()));

                        Session["class_name"] = c_teacher_RDD.SelectedItem.Text;

                    }
                    create_class_site(Session["class_id"].ToString());
                    break;


            }

            var class_id = Guid.Parse(Session["class_id"].ToString());

            var departmentType = pe.Department.SingleOrDefault(o => o.Id == class_id).Type;

            if (departmentType != DepartmentType.班级)
            {
                string boot_url = GetResourceUrl("SsoUrl");

                var url = string.Format("{0}/Board", boot_url);

                Session.Clear();

                Response.Write(string.Format("<script>alert('登陆失败');top.location.href='{0}';</script>", url));

                Response.End();
            }
            
        }
        AlbumInit();

    }
    protected void AlbumInit()
    {

        BasePage bp = new BasePage();

        string DefaultUrl = "img/AlnumDefault.png";

        var ClassId = Guid.Parse(this.Session["class_id"].ToString());

        var AlbumObj = pe.Album.Where(o => o.ClassId == ClassId && o.State < State.审核).ToList();

        if (AlbumObj == null || AlbumObj.Count() == 0)
        {

            Album al = new Album();

            al.AlbumId = Guid.NewGuid();

            al.AlbumName = "班级活动";

            al.ClassId = ClassId;

            al.CreateTime = DateTime.Now;

            al.DefaultUrl = DefaultUrl;

            al.IsDefault = true;

            al.Remark = "此为班级活动相册，保存该班级所有的班级活动图片";

            al.State = State.启用;

            pe.Album.Add(al);

            pe.SaveChanges();

        }


    }



    protected string SetGradeSession(Guid class_id)
    {


        return pe.Department.First(o => o.Id == class_id).ParentId.ToString();


    }
    protected Lazy<Entities> HomoryContext = new Lazy<Entities>(() => new Entities());



    /// <summary>
    /// 页面初始化
    /// </summary>
    private void TM_PageInit()
    {

        var user_id = Guid.Parse(Session["user_id"].ToString());

        this.Session["User"] = CurrentUser;

        this.UserId.Text = user_id.ToString();

        var user_name = CurrentUser.RealName;

        var final_user_name = string.Empty;

        var min = DateTime.Today < new DateTime(DateTime.Today.Year, 8, 1) ? DateTime.Today.Year : DateTime.Today.Year + 1;

        var max = min + GetYears(CurrentCampus);

        min -= 1;

        switch (GetAuth())
        {
            case 0:
            case 5:
                final_user_name = surname_check(user_name.Substring(0, 2)) ? user_name.Substring(0, 2) + "老师,您好(班主任)" : user_name.Substring(0, 1) + "老师,您好(班主任)";

                var banDs = HomoryContext.Value.教师所在班级以及所教学科视图.Where(o => o.UserId == user_id).ToList().Select(
                o => new
                {
                    Id = o.DepartmentId+"|"+ o.CourseId,
                    Name = findStartYear(o.Ordinal, o.ClassType) + " "+o.ClassName
                }).ToList();

                this.c_teacher_RDD.DataSource = banDs;

                break;
            case 1:
                banDs = HomoryContext.Value.教师所在班级以及所教学科视图.Where(o => o.UserId == user_id).ToList().Select(
                o => new
                {
                    Id = o.DepartmentId + "|" + o.CourseId,
                    //Name = o.Name
                    Name = findStartYear(o.Ordinal, o.ClassType) + " " + o.ClassName
                    //Name = o.Ordinal + "届" + o.ClassName
                }).ToList();

                this.c_teacher_RDD.DataSource = banDs;

                final_user_name = surname_check(user_name.Substring(0, 2)) ? user_name.Substring(0, 2) + "老师,您好" : user_name.Substring(0, 1) + "老师,您好";
                break;
            case 2:
                final_user_name = user_name + ",您好";

                this.c_teacher_RDD.DataSource = HomoryContext.Value.DepartmentUser.Where(o => o.UserId == user_id && o.Type == DepartmentUserType.班级学生 && (o.State < State.审核 || o.State == State.历史)).ToList().Join(HomoryContext.Value.Department, o => o.DepartmentId, x => x.Id, (o, x) => new
                    {
                        Id = string.Format("{0}", o.DepartmentId),

                        //Name = o.Department.DepartmentParent.Name  + x.Name

                        Name = findStartYear(o.Department.DepartmentParent.Ordinal,(int)o.Department.DepartmentParent.ClassType)+" "+x.Name

                    }).OrderBy(o=>o.Name).ToList();

                break;

            default:

                string boot_url = GetResourceUrl("SsoUrl");

                var url = string.Format("{0}/Board", boot_url);

                Session.Clear();

                Response.Write(string.Format("<script>alert('暂无授课班级');top.location.href='{0}';</script>", url));

                Response.End();

                return;
        }

        this.u_displayname_L.Text = final_user_name;

        this.c_teacher_RDD.DataBind();

    }
    public int findStartYear(int year, int classType)
    {
        switch ((ClassType)classType)
        {
            case ClassType.九年一贯制:
                return year - 6;
            default: return year -3;
        }
    }

    public bool ShowSearchBox
    {
        get
        {
            return this.search_content_RSB.Visible;
        }
        set
        {
            this.search_content_RSB.Visible = value;
        }
    }



    protected void c_teacher_RDDL_SelectedIndexChanged(object sender, DropDownListEventArgs e)
    {
        var value = e.Value.Split(new char[] { '|' });

        create_class_site(value[0]);

        Session["class_id"] = value[0];

        Session["grade_id"] = SetGradeSession(Guid.Parse(Session["class_id"].ToString()));

        Session["course_id"] = value.Length > 1 ? value[1] : null;

        Response.Redirect(Request.Url.AbsolutePath);

    }
    protected void search_content_RSB_Search(object sender, SearchBoxEventArgs e)
    {

        var text = search_content_RSB.Text;

        var data = text + "|5|1";

        (this.Page.FindControl("classMain").FindControl("contents") as RadAjaxPanel).RaisePostBackEvent(data);
    }

    private void create_class_site(string class_id_str)
    {

        Guid class_id = Guid.Parse(class_id_str);

        C_site_config csc = pe.C_site_config.SingleOrDefault(o => o.ClassId == class_id);

        if (csc == null)
        {
            csc = new C_site_config();

            csc.Id = Guid.NewGuid();

            csc.ClassId = class_id;

            csc.Datetime = DateTime.Now;

            csc.Kcontent = string.Empty;

            csc.Message = string.Empty;

            csc.QQ = string.Empty;

            csc.Thumbnail = string.Empty;

            csc.Url = string.Empty;

            csc.Weixin = string.Empty;

            csc.Wximg = string.Empty;

            pe.C_site_config.Add(csc);

            pe.SaveChanges();

        }

    }



    protected void btnSignOut_ServerClick(object sender, EventArgs e)
    {
        try
        {
            var url = string.Format("{0}/SignOff?SsoRedirect={1}", base_url, Server.UrlEncode(string.Format("{0}/SignOn", base_url)));
            Response.Redirect(url, false);
            Session.Clear();
        }
        catch (Exception)
        {
            var url = string.Format("{0}/SignOff?SsoRedirect={1}", base_url, Server.UrlEncode(string.Format("{0}/SignOn", base_url)));
            Response.Redirect(url, false);
        }
        
    }

    protected int GetPacketCount()
    {
        var UserId = Guid.Parse(this.Session["user_id"].ToString());

        return pe.C_call.Where(o => o.ReceiverID == UserId && o.State < State.审核 && o.isRead == false).ToList().Count();

    }
    protected void PacketTimer_Tick(object sender, EventArgs e)
    {
        lblCount.Text = GetPacketCount().ToString();
    }

    public RadSearchBox Searcher { get { return this.search_content_RSB; } }
}