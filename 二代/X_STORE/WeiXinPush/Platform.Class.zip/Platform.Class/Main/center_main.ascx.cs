﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;
using System.IO;
using System.Text.RegularExpressions;
using Homory.Model;

public partial class Main_center_main : BaseControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageInit();
        
        }
    }


    Model model = new Model();

    private Entities _db;

    protected Entities db
    {
        get
        {
            if (_db == null)
                _db = new Entities();
            return _db;
        }
    }
   
    protected string GetImgUrl()
    {
        switch (GetAuth())
        {
            case 2: return "img/xue.png";
            case 5:return "img/其他.png";
            default:
                var courseId = Guid.Parse(this.Session["course_id"].ToString());
                var courseName = db.Catalog.SingleOrDefault(o => o.Id == courseId).Name.ToString();
                return "img/" + courseName + ".png";
        }
    }

    protected List<C_Adjunct> GetA(Guid id,int num)
    {
      return  db.C_Adjunct.Where(o => o.ContentId == id && o.Type == num).ToList();
    }

    protected string GetFileName(string url)
    {

        if (string.Empty.Equals(url))
        {
            return string.Empty;
        }

        var url_list = url.Split('/');

        return url_list[url_list.Length - 1].Substring(37).ToString();

    }
    /// <summary>
    /// 页面初始化
    /// </summary>
    private void PageInit(string text = "",int count = 5,int zj_type = 0)
    {
      
        isDisplay();

        this.Session["content_type"] = this.ClassType;

        this.ClassTypeTB.Text = this.ClassType;

        this.UserId.Text = this.Session["user_id"].ToString();

        popup_attachment.NavigateUrl = "Popup/PublishAttachment.aspx";

        var user_id = Guid.Parse(Session["user_id"].ToString());

        var class_id = Guid.Parse(Session["class_id"].ToString());

        var content_list = model.FindContentByClassId(class_id, Convert.ToInt32(this.ClassType), count,zj_type, text );

        this.content_R.DataSource = content_list;

        this.content_R.DataBind();    
       
    }

    private void isDisplay() {

        switch (GetAuth())
        {

            case 0:
            case 1:
            case 5:
                break;
            case 2:
                this.content_issue_div.Style.Value = "display:none;";
                break;
            default:
                break;
        }

    }

    protected bool isVisiable(string contentId) {

        var content_id = Guid.Parse(contentId);

        var content = db.View_Content.Where(o => o.Id == content_id && o.UserId == CurrentUser.Id).ToList();

        switch (GetAuth())
        {
            case 0:

                return true;

            case 1:
                if (content.Count>0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            case 2:

                return false;

            default:
                return true;
        }
        
    
    }

    protected List<View_ContentResource> GetResource(Guid id)
    {

        DataTable dt = new DataTable();

        var content_resource_list = db.View_ContentResource.Where(o => o.ContentId == id).ToList();

        return content_resource_list;

    }

    protected string GetRequestUrl(int type,string resource_id) {

        string boot_url = GetResourceUrl("ResourceUrl");

        string final_url = string.Empty;

        switch (type)
        {

            case 1: final_url = boot_url + "/ClassViewVideo.aspx?Id=" + resource_id + ""; break;

            case 2: final_url = boot_url + "/ClassViewPlain.aspx?Id=" + resource_id + ""; break;

            default:
                break;
        }
        return final_url;
    }

    public string ClassType{ get;set;}

    protected string GetPageType() {

        string str = string.Empty;

        switch (Convert.ToInt32(ClassType))
        {

            case 1: str = "课堂作业"; break;
            case 2: str = "班级活动"; break;
            default: str = "课堂作业"; break;
        }
        return str;
        
    }
    /// <summary>
    /// 评论发布事件
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void comment_issue_B_Command(object sender, CommandEventArgs e)
    {

        string content_id = e.CommandName.ToString();


    }

    protected string GetPlayerImg(string src)
    {

        if ( src == null||src.Equals(string.Empty))
        {
            return string.Empty;
        }
        else
        {
            return "img/video.png";
        }
    
    }
    //protected string GetMovieUrl(string pic_url, string movie_url)
    //{
    //    var server_movie_url = Server.MapPath(movie_url.Substring(3));

    //    if (File.Exists(server_movie_url))
    //    {
    //        return pic_url;
    //    }
    //    else
    //    {
    //        return "img/shipin.gif";
    //    }
    
    //}
    /// <summary>
    /// 页面刷新
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void refresh_B_Click(object sender, EventArgs e)
    {
        PageInit();
    }
    protected void contents_AjaxRequest(object sender, Telerik.Web.UI.AjaxRequestEventArgs e)
    {

        string[] data = e.Argument.Split('|');    
    
        PageInit(data[0],Convert.ToInt32(data[1]),Convert.ToInt32(data[2]));

        contents.ResponseScripts.Add("bind_a();"); 

    }

    protected string get_collect(string content_id_str) {

        Guid content_id = Guid.Parse(content_id_str);

        Guid user_id = Guid.Parse(Session["user_id"].ToString());


        ///////////////////  ERROR

        C_Collect cc = db.C_Collect.FirstOrDefault(o=>o.UserId == user_id && o.ContentId == content_id);

        bool collect_b = false;

        if (cc != null)
        {
            collect_b = cc.isCollect;
        }
        return collect_b ? "取消收藏" : "收藏";
    }

    protected string get_collect_class(string content_id_str)
    {

        Guid content_id = Guid.Parse(content_id_str);

        Guid user_id = Guid.Parse(Session["user_id"].ToString());

        ///////////////////  ERROR

        C_Collect cc = db.C_Collect.FirstOrDefault(o => o.UserId == user_id && o.ContentId == content_id);

        bool collect_b = false;

        if (cc != null)
        {
            collect_b = cc.isCollect;
        }
        return collect_b ? "fa fa-star" : "fa fa-star-o";
    }
    protected string get_read(string content_id_str)
    {
        Guid content_id = Guid.Parse(content_id_str);

        Guid user_id = Guid.Parse(Session["user_id"].ToString());

        ///////////////////  ERROR

        C_Collect cc = db.C_Collect.FirstOrDefault(o => o.UserId == user_id && o.ContentId == content_id);

        bool read_b = false;

        if (cc != null)
        {
            read_b = cc.isRead;
        }
        return read_b ? "已阅" : "标注已阅";

    }

    protected int get_collect_count(string content_id_str) {

        Guid content_id = Guid.Parse(content_id_str);

        Guid user_id = Guid.Parse(Session["user_id"].ToString());

        var cc_list = db.C_Collect.Where(o => o.isCollect == true && o.ContentId == content_id).ToList();

        int collect_count = 0;

        if (cc_list != null)
        {
            collect_count = cc_list.Count();
        }

        return collect_count;

    }

    protected int get_read_count(string content_id_str)
    {

        Guid content_id = Guid.Parse(content_id_str);

        Guid user_id = Guid.Parse(Session["user_id"].ToString());

        var cc_list = db.C_Collect.Where(o => o.isRead == true && o.ContentId == content_id).ToList();

        int read_count = 0;

        if (cc_list != null)
        {
            read_count = cc_list.Count();
        }

        return read_count;

    }
    //protected int IsExists(string src)
    //{
    //    if (File.Exists(Server.MapPath(src.Substring(3))))
    //    {
    //        return 1;
    //    }
    //    else
    //    {
    //        return 0;
    //    }
    //}
    protected string isDisplay(string ContentId,int type) {

        Guid content_id = Guid.Parse(ContentId);

        string style = "style\"display:\"";

        //db.C_Adjunct.Where(o=>o.C);


        return style;
    }

    protected void moviePlayerServerClick(object sender, EventArgs e)
    {
        dynamic player = ((sender as System.Web.UI.HtmlControls.HtmlAnchor).NamingContainer.NamingContainer.NamingContainer).FindControl("XsfxPlayer");
        player.Video = (sender as System.Web.UI.HtmlControls.HtmlAnchor).Attributes["data-id"];
    }
    //protected void new_info_AjaxRequest(object sender, AjaxRequestEventArgs e)
    //{
    //    if(e.Argument=="New")
    //    {
    //        new_info.Visible = true;
    //    }
    //}
}