﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class TokenCheck : System.Web.UI.Page
{
    string Token = "Se1f_99";
    protected void Page_Load(object sender, EventArgs e)
    {
        Valid();
       // MyMenu();
        Response.Write("<script>alert(1)</script>");
        //wxmessage wx = GetWxMessage();
        //string res = "";

        //if (!string.IsNullOrEmpty(wx.EventName) && wx.EventName.Trim() == "subscribe")
        //{//刚关注时的时间，用于欢迎词  
        //    string content = "";
        //    content = "/:rose欢迎北京永杰友信科技有限公司/:rose\n直接回复“你好”";
        //    res = sendTextMessage(wx, content);
        //}
        //else
        //{
        //    if (wx.MsgType == "text" && wx.Content == "你好")
        //    {
        //        res = sendTextMessage(wx, "你好,欢迎使用北京永杰友信科技有限公司公共微信平台!");
        //    }
        //    else
        //    {
        //        res = sendTextMessage(wx, "你好,未能识别消息!");
        //    }
        //}

        //Response.Write(res);  
    }
    public void MyMenu()
    {
        string weixin1 = "";
        weixin1 = @" {  
     ""button"":[  
     {    
          ""type"":""click"",  
          ""name"":""你好!"",  
          ""key"":""Hello""  
      },  
      {  
           ""type"":""view"",  
           ""name"":""公司简介"",  
           ""url"":""http://www.4ugood.net""  
      },  
      {  
           ""name"":""产品介绍"",  
           ""sub_button"":[  
            {  
               ""type"":""click"",  
               ""name"":""产品1"",  
                ""key"":""P1""  
            },  
            {  
               ""type"":""click"",  
               ""name"":""产品2"",  
               ""key"":""P2""  
            }]  
       }]  
 }  
";

        string access_token = IsExistAccess_Token();
        string i = GetPage("https://api.weixin.qq.com/cgi-bin/menu/create?access_token=" + access_token, weixin1);
        Response.Write(i);
    }
    private void Valid()
    {
        string echoStr = Request.QueryString["echoStr"].ToString();
        if (CheckSignature())
        {
            if (!string.IsNullOrEmpty(echoStr))
            {
                Response.Write(echoStr);
                Response.End();
            }
        }
    }
    private bool CheckSignature()
    {
        string signature = Request.QueryString["signature"].ToString();
        string timestamp = Request.QueryString["timestamp"].ToString();
        string nonce = Request.QueryString["nonce"].ToString();
        string[] ArrTmp = { Token, timestamp, nonce };
        Array.Sort(ArrTmp);     //字典排序  
        string tmpStr = string.Join("", ArrTmp);
        tmpStr = FormsAuthentication.HashPasswordForStoringInConfigFile(tmpStr, "SHA1");
        tmpStr = tmpStr.ToLower();
        if (tmpStr == signature)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
  
    /// <summary>  
    /// 根据当前日期 判断Access_Token 是否超期  如果超期返回新的Access_Token   否则返回之前的Access_Token  
    /// </summary>  
    /// <param name="datetime"></param>  
    /// <returns></returns>  
    public static string IsExistAccess_Token()
    {

        string Token = string.Empty;
        DateTime YouXRQ;
        // 读取XML文件中的数据，并显示出来 ，注意文件路径  
        string filepath = HttpContext.Current.Server.MapPath("XMLFile.xml");

        StreamReader str = new StreamReader(filepath, System.Text.Encoding.UTF8);
        XmlDocument xml = new XmlDocument();
        xml.Load(str);
        str.Close();
        str.Dispose();
        Token = xml.SelectSingleNode("xml").SelectSingleNode("Access_Token").InnerText;
        YouXRQ = Convert.ToDateTime(xml.SelectSingleNode("xml").SelectSingleNode("Access_YouXRQ").InnerText);

        if (DateTime.Now > YouXRQ)
        {
            DateTime _youxrq = DateTime.Now;
            Access_token mode = GetAccess_token();
            xml.SelectSingleNode("xml").SelectSingleNode("Access_Token").InnerText = mode.access_token;
            _youxrq = _youxrq.AddSeconds(int.Parse(mode.expires_in));
            xml.SelectSingleNode("xml").SelectSingleNode("Access_YouXRQ").InnerText = _youxrq.ToString();
            xml.Save(filepath);
            Token = mode.access_token;
        }
        return Token;
    }  
    /// <summary>
    /// 动态获取access_token值，由于access_token是有时效性的
    /// </summary>
    /// <returns></returns>
    public static Access_token GetAccess_token()
    {
        string appid = "wx5769287cfe0fd655";
        string secret = "7250f97d95e92aa1290f0a3915b75906";
        string strUrl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + appid + "&secret=" + secret;
        Access_token mode = new Access_token();

        HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(strUrl);

        req.Method = "GET";
        using (WebResponse wr = req.GetResponse())
        {
            HttpWebResponse myResponse = (HttpWebResponse)req.GetResponse();

            StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.UTF8);

            string content = reader.ReadToEnd();
            //Response.Write(content); 
            //在这里对Access_token 赋值 
            Access_token token = new Access_token();
            token = JsonHelper.ParseFromJson<Access_token>(content);
            mode.access_token = token.access_token;
            mode.expires_in = token.expires_in;
        }
        return mode;
    }

    /// <summary>  
    /// 写日志(用于跟踪)  
    /// </summary>  
    private void WriteLog(string strMemo)
    {
        string filename = Server.MapPath("/logs/log.txt");
        if (!Directory.Exists(Server.MapPath("//logs//")))
            Directory.CreateDirectory("//logs//");
        StreamWriter sr = null;
        try
        {
            if (!File.Exists(filename))
            {
                sr = File.CreateText(filename);
            }
            else
            {
                sr = File.AppendText(filename);
            }
            sr.WriteLine(strMemo);
        }
        catch
        {

        }
        finally
        {
            if (sr != null)
                sr.Close();
        }
    }
    public string GetPage(string posturl, string postData)
    {
        Stream outstream = null;
        Stream instream = null;
        StreamReader sr = null;
        HttpWebResponse response = null;
        HttpWebRequest request = null;
        Encoding encoding = Encoding.UTF8;
        byte[] data = encoding.GetBytes(postData);
        // 准备请求...  
        try
        {
            // 设置参数  
            request = WebRequest.Create(posturl) as HttpWebRequest;
            CookieContainer cookieContainer = new CookieContainer();
            request.CookieContainer = cookieContainer;
            request.AllowAutoRedirect = true;
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = data.Length;
            outstream = request.GetRequestStream();
            outstream.Write(data, 0, data.Length);
            outstream.Close();
            //发送请求并获取相应回应数据  
            response = request.GetResponse() as HttpWebResponse;
            //直到request.GetResponse()程序才开始向目标网页发送Post请求  
            instream = response.GetResponseStream();
            sr = new StreamReader(instream, encoding);
            //返回结果网页（html）代码  
            string content = sr.ReadToEnd();
            string err = string.Empty;
            return content;
        }
        catch (Exception ex)
        {
            string err = ex.Message;
            Response.Write(err);
            return string.Empty;
        }
    }
    private wxmessage GetWxMessage()
    {
        wxmessage wx = new wxmessage();
        StreamReader str = new StreamReader(Request.InputStream, System.Text.Encoding.UTF8);
        XmlDocument xml = new XmlDocument();
        xml.Load(str);
        wx.ToUserName = xml.SelectSingleNode("xml").SelectSingleNode("ToUserName").InnerText;
        wx.FromUserName = xml.SelectSingleNode("xml").SelectSingleNode("FromUserName").InnerText;
        wx.MsgType = xml.SelectSingleNode("xml").SelectSingleNode("MsgType").InnerText;
        if (wx.MsgType.Trim() == "text")
        {
            wx.Content = xml.SelectSingleNode("xml").SelectSingleNode("Content").InnerText;
        }
        if (wx.MsgType.Trim() == "event")
        {
            wx.EventName = xml.SelectSingleNode("xml").SelectSingleNode("Event").InnerText;
        }


        return wx;
    }

    /// <summary>   
    /// 发送文字消息   
    /// </summary>   
    /// <param name="wx">获取的收发者信息   
    /// <param name="content">内容   
    /// <returns></returns>   
    private string sendTextMessage(wxmessage wx, string content)
    {
        string res = string.Format(@" ",
            wx.FromUserName, wx.ToUserName, DateTime.Now, content);
        return res;
    } 
}