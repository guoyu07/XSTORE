﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Homory.Model;

public partial class TimeTableManage : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageInit();           
        }
    }
    private void PageInit()
    {
        Guid class_id = Guid.Parse(this.Session["class_id"].ToString());

        C_site_config csc = db.C_site_config.SingleOrDefault(o => o.ClassId == class_id);

        if (csc!=null &&csc.Kcontent != null && !string.Empty.Equals(csc.Kcontent))
        {
            var timetable_list = csc.Kcontent.Split(new char[] { ',' });

            var class_timetable_label_list = class_timetable_manage_P.Controls.OfType<TextBox>().Select(o => o).ToList();

            for (int i = 0; i < timetable_list.Count(); i++)
            {
                class_timetable_label_list[i].Text = timetable_list[i];
            }
        }
    }
    protected void submit_B_Click(object sender, EventArgs e)
    {
        Guid class_id = Guid.Parse(this.Session["class_id"].ToString());

        string Kcontent = (class_timetable_manage_P.Controls.OfType<TextBox>().Select(o => o.Text).Aggregate<string, string, string>("", (o1, o2) => o1 += o2 + ",", o => o.Substring(0, o.Length - 1)));

        C_site_config csc = db.C_site_config.SingleOrDefault(o => o.ClassId == class_id);

        if (csc == null)
        {
            csc = new C_site_config();

            csc.Id = Guid.NewGuid();

            csc.ClassId = class_id;

            csc.Kcontent = Kcontent;

            csc.Datetime = DateTime.Now;

            db.C_site_config.Add(csc);
        }
        else
        {
            csc.Kcontent = Kcontent;
        }

        db.SaveChanges();

        this.class_timetable_manage_P.ResponseScripts.Add("alert('添加或修改成功');");

    }
}