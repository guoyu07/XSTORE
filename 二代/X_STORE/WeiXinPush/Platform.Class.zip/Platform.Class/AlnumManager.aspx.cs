﻿using Homory.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AlnumManager : BasePage
{


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageInit();

            TimeClassInit();
        }
    }

    protected void TimeClassInit() {

        this.YearTimeRepeater.DataSource = GetTimeList().Select(o => new
        {
           Time = Convert.ToDateTime(o.CreateTime).Year

        }).Distinct().ToList();

        this.YearTimeRepeater.DataBind();
        
        this.BodyRepeater.DataSource = GetTimeList().Select(o => new
        {
            Time = Convert.ToDateTime(o.CreateTime).Year

        }).Distinct().ToList();

        this.BodyRepeater.DataBind();


    }

    protected List<AlbumResource> FindAlbumClass(string Year) {

        return GetTimeList().Where(o => Convert.ToDateTime(o.CreateTime).Year.ToString() == Year).ToList();

    }

    private List<AlbumResource> GetTimeList() {

        return db.AlbumResource.GroupBy(o => o.CreateDate).Select(o => o.FirstOrDefault()).OrderByDescending(o => o.CreateDate).ToList();

    }
    protected string Display()
    {

        if (GetAuth() == 0 || GetAuth() == 5)
        {
            return "display:block";
        }
        else
        {
            return "display:none";
        }
    }

    protected void PageInit() {

        Clear();

        var ALO = db.View_AlbumList.Where(o => o.ClassId == ClassId).ToList().OrderByDescending(o => o.CreateTime);

        this.AlnumRepeater.DataSource = ALO;

        this.AlnumRepeater.DataBind();
    
    }
  
    protected void Clear() {

        this.AlbumName.Text = string.Empty;

        this.AlbumDescribe.Text = string.Empty;
    
    }
    protected void albumAjaxPanel_AjaxRequest(object sender, Telerik.Web.UI.AjaxRequestEventArgs e)
    {
        PageInit();

        albumAjaxPanel.ResponseScripts.Add("autosize();");

    }
}