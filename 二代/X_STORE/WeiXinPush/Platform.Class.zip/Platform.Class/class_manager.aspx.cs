﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Homory.Model;

public partial class Navigation_class_manager : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageInit();
        }
    }


    protected void PageInit() {

        clear_message();

        Guid class_id = Guid.Parse(this.Session["class_id"].ToString());

        C_site_config csc = db.C_site_config.SingleOrDefault(o => o.ClassId == class_id);

        if (csc != null)
        {
            this.qq_group_num_I.Value = csc.QQ;

            this.weixin_num_I.Value = csc.Weixin;

            this.weixin_barcode_I.Value = csc.Wximg;

            this.tearch_saying_TA.Value = csc.Message;

            this.SiteLogoUrl.Value = csc.Url;

            this.SiteThumbnailUrl.Value = csc.Thumbnail;

            string[] pics = csc.Url.Split('|');

            string[] suo_pics = csc.Thumbnail.Split('|');

            string[] barcode_pic = csc.Wximg.Split('|');

            for (int i = 0; i < pics.Count(); i++)
			{
                if (string.Empty.Equals(pics[i]))
                {
                    continue;
                }
                picture_div.InnerHtml += string.Format("<div style='float:left; position:relative; margin-right:5px'><img style='width:120px; height:90px;' id='{1}' class='picture_img_class'  src='{0}'/> <a style='position:absolute; right:0; top:0;' href='javascript:void(0);' onclick='delete_content_picture(this)'><img style='width:20px;heigth:20px;' src='img/delete.png'/></a></div>", suo_pics[i], pics[i]);
			}
            for (int j = 0; j < barcode_pic.Count(); j++)
            {
                if (string.Empty.Equals(barcode_pic[j]))
                {
                    continue;
                }

                barcode_div.InnerHtml += string.Format("<div style='float:left; position:relative; margin-right:5px'><img  style='width:120px; height:90px;' class='picture_img_class'  src='{0}'/> <a style='position:absolute; right:0; top:0;' href='javascript:void(0);' onclick='delete_content_picture(this)'><img style='width:20px;heigth:20px;' src='img/delete.png'/></a></div>", barcode_pic[j]);
            }
        }
    }

    protected void clear_message() {

        this.SiteLogoUrl.Value = string.Empty;

        this.qq_group_num_I.Value = string.Empty;

        this.weixin_num_I.Value = string.Empty;

        this.weixin_barcode_I.Value =string.Empty;

        this.tearch_saying_TA.Value = string.Empty;
    }

}