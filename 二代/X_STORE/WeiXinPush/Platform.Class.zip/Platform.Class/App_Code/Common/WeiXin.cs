﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Xml;
using Newtonsoft.Json;
using System.Xml.Linq;
using System.Web.Script.Serialization;


/// <summary>
/// WeiXin 的摘要说明
/// </summary>
public class WeiXin
{
    string Token = "Se1f_99";

    public string weixin_url = System.Configuration.ConfigurationManager.AppSettings["WeiXinUrl"].ToString();

    public static string appid = System.Configuration.ConfigurationManager.AppSettings["AppId"].ToString();

    public static string secret = System.Configuration.ConfigurationManager.AppSettings["AppSecret"].ToString();

    public string weixin_title = System.Configuration.ConfigurationManager.AppSettings["WeiXinTitle"].ToString();

    public string class_work_template_id = System.Configuration.ConfigurationManager.AppSettings["cwTemplateId"].ToString();

    public string set_work_template_id = System.Configuration.ConfigurationManager.AppSettings["swTemplateId"].ToString();

    public string send_packet_template_id = System.Configuration.ConfigurationManager.AppSettings["spTemplateId"].ToString();

    public WeiXin()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
    public void Valid()
    {
        string echoStr = HttpContext.Current.Request.QueryString["echoStr"].ToString();
        if (CheckSignature())
        {
            if (!string.IsNullOrEmpty(echoStr))
            {
                HttpContext.Current.Response.Write(echoStr);
                HttpContext.Current.Response.End();
            }
        }
    }
    private bool CheckSignature()
    {
        string signature = HttpContext.Current.Request.QueryString["signature"].ToString();
        string timestamp = HttpContext.Current.Request.QueryString["timestamp"].ToString();
        string nonce = HttpContext.Current.Request.QueryString["nonce"].ToString();
        string[] ArrTmp = { Token, timestamp, nonce };
        Array.Sort(ArrTmp);     //字典排序  
        string tmpStr = string.Join("", ArrTmp);
        tmpStr = FormsAuthentication.HashPasswordForStoringInConfigFile(tmpStr, "SHA1");
        tmpStr = tmpStr.ToLower();
        if (tmpStr == signature)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    /// <summary>  
    /// 根据当前日期 判断Access_Token 是否超期  如果超期返回新的Access_Token   否则返回之前的Access_Token  
    /// </summary>  
    /// <param name="datetime"></param>  
    /// <returns></returns>  
    public static string IsExistAccess_Token()
    {

        string Token = string.Empty;
        DateTime YouXRQ;
        // 读取XML文件中的数据，并显示出来 ，注意文件路径  
        string filepath = HttpContext.Current.Server.MapPath("XMLFile.xml");

        StreamReader str = new StreamReader(filepath, System.Text.Encoding.UTF8);
        XmlDocument xml = new XmlDocument();
        xml.Load(str);
        str.Close();
        str.Dispose();
        Token = xml.SelectSingleNode("xml").SelectSingleNode("Access_Token").InnerText;
        YouXRQ = Convert.ToDateTime(xml.SelectSingleNode("xml").SelectSingleNode("Access_YouXRQ").InnerText);

        if (DateTime.Now > YouXRQ)
        {
            DateTime _youxrq = DateTime.Now;
            Access_token mode = GetAccess_token();
            xml.SelectSingleNode("xml").SelectSingleNode("Access_Token").InnerText = mode.access_token;
            _youxrq = _youxrq.AddSeconds(int.Parse(mode.expires_in));
            xml.SelectSingleNode("xml").SelectSingleNode("Access_YouXRQ").InnerText = _youxrq.ToString();
            xml.Save(filepath);
            Token = mode.access_token;
        }
        return Token;
    }
    /// <summary>
    /// 动态获取access_token值，由于access_token是有时效性的
    /// </summary>
    /// <returns></returns>
    public static Access_token GetAccess_token()
    {
        
        string strUrl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + appid + "&secret=" + secret;
        
        Access_token mode = new Access_token();

        HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(strUrl);

        req.Method = "GET";

        using (WebResponse wr = req.GetResponse())
        {
            HttpWebResponse myResponse = (HttpWebResponse)req.GetResponse();

            StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.UTF8);

            string content = reader.ReadToEnd();
            //在这里对Access_token 赋值 
            Access_token token = new Access_token();

            token = JsonHelper.ParseFromJson<Access_token>(content);

            mode.access_token = token.access_token;

            mode.expires_in = token.expires_in;
        }
        return mode;
    }
    /// <summary>
    /// 根据access_token值和openId获取用户信息
    /// </summary>
    /// <param name="access_token"></param>
    /// <param name="openId"></param>
    /// <returns></returns>
    public UserInfo GetUserInfoByOpenId(string access_token,string openId) {

        UserInfo ui = new UserInfo();

        var url = string.Format("https://api.weixin.qq.com/cgi-bin/user/info?access_token={0}&openid={1}&lang=zh_CN", access_token, openId);

        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

        request.Accept = "*/*";

        request.KeepAlive = true;

        //上面的http头看情况而定，但是下面俩必须加
        request.ContentType = "application/x-www-form-urlencoded";

        request.Method = "GET";

        Encoding encoding = Encoding.UTF8;//根据网站的编码自定义

        request.ContentLength = 0;

        HttpWebResponse response = (HttpWebResponse)request.GetResponse();

        Stream responseStream = response.GetResponseStream();

        StreamReader streamReader = new StreamReader(responseStream, encoding);

        string retString = streamReader.ReadToEnd();

        streamReader.Close();

        responseStream.Close();

        JavaScriptSerializer js = new JavaScriptSerializer();

        ui = js.Deserialize<UserInfo>(retString);

        return ui;

    
    }
    public string GetOpenId(string code)
    {

        var url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=" + appid + "&secret=" + secret + "&code=" + code + "&grant_type=authorization_code";
      
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

        request.Accept = "*/*";

        request.KeepAlive = true;

        //上面的http头看情况而定，但是下面俩必须加
        request.ContentType = "application/x-www-form-urlencoded";

        request.Method = "GET";

        Encoding encoding = Encoding.UTF8;//根据网站的编码自定义

        request.ContentLength = 0;

        HttpWebResponse response = (HttpWebResponse)request.GetResponse();

        Stream responseStream = response.GetResponseStream();

        StreamReader streamReader = new StreamReader(responseStream, encoding);

        string retString = streamReader.ReadToEnd();

        streamReader.Close();

        responseStream.Close();

        JavaScriptSerializer js = new JavaScriptSerializer();

        OAuthClass oac = js.Deserialize<OAuthClass>(retString);

        return oac.openid;

    }
    public void RequestPlate(string postData)
    {
              
        var access_token = WeiXin.GetAccess_token().access_token;

        var url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=" + access_token;

        System.Net.HttpWebRequest request = default(System.Net.HttpWebRequest);  

        System.IO.Stream requestStream = default(System.IO.Stream);

        byte[] postBytes = Encoding.UTF8.GetBytes(postData.ToString());
        //byte[] postBytes = null;

        request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(url);

        request.ContentType = "application/x-www-form-urlencoded;charset=utf8";

        request.ContentLength = postBytes.Length;  

        request.Timeout = 10000;  

        request.Method = "POST";  

        request.AllowAutoRedirect = false;  
  
        requestStream = request.GetRequestStream();

       // postBytes = Encoding.ASCII.GetBytes(postData.ToString());

        //string finalPost = System.Text.Encoding.UTF8.GetString(postBytes);

        requestStream.Write(postBytes, 0, postBytes.Length);  

        requestStream.Close();  
    
    }
 
    public wxmessage GetWxMessage()
    {

        wxmessage wx = new wxmessage();

        StreamReader str = new StreamReader(HttpContext.Current.Request.InputStream, System.Text.Encoding.UTF8);

        XmlDocument xml = new XmlDocument();

        xml.Load(str);

        wx.ToUserName = xml.SelectSingleNode("xml").SelectSingleNode("ToUserName").InnerText;

        wx.FromUserName = xml.SelectSingleNode("xml").SelectSingleNode("FromUserName").InnerText;

        wx.MsgType = xml.SelectSingleNode("xml").SelectSingleNode("MsgType").InnerText;

        if (wx.MsgType.Trim() == "text")
        {
            wx.Content = xml.SelectSingleNode("xml").SelectSingleNode("Content").InnerText;
        }
        if (wx.MsgType.Trim() == "event")
        {
            wx.EventName = xml.SelectSingleNode("xml").SelectSingleNode("Event").InnerText;
        }

        return wx;
    }

    /// <summary>    
    /// 发送文字消息    
    /// </summary>    
    /// <param name="wx">获取的收发者信息    
    /// <param name="content">内容    
    /// <returns></returns>    
    public string sendTextMessage(wxmessage wx, string content)
    {
        string res = string.Format(@"<xml>"
            + "<ToUserName><![CDATA[{0}]]></ToUserName>"
            + "<FromUserName><![CDATA[{1}]]></FromUserName>"
            + "<CreateTime>{2}</CreateTime>"
            + "<MsgType><![CDATA[text]]></MsgType>"
            + "<Content><![CDATA[{3}]]></Content>"
            + "</xml>",
            wx.FromUserName, wx.ToUserName, DateTime.Now, content);
        return res;
    } 
}