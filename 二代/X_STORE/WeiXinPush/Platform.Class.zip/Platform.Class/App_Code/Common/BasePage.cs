﻿using Homory.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// BasePage 的摘要说明
/// </summary>
public class BasePage:System.Web.UI.Page
{
	public BasePage()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    protected string weixin_url = System.Configuration.ConfigurationManager.AppSettings["WeiXinUrl"].ToString();

    protected string base_url = System.Configuration.ConfigurationManager.AppSettings["SsoUrl"].ToString();

    private Entities _db;

    protected Entities db
    {
        get
        {
            if (_db == null)
                _db = new Entities();
            return _db;
        }
    }
    /// <summary>
    /// 当前用户
    /// </summary>
    protected User CurrentUser
    {
        
        get
        {
            try
            {
                var id = Guid.Parse(Session["user_id"].ToString());

                return db.User.Single(o => o.Id == id);

            }
            catch (Exception)
            {
                var url = string.Format("{0}/SignOff?SsoRedirect={1}", base_url, Server.UrlEncode(string.Format("{0}/SignOn", base_url)));

                Response.Redirect(url, false);

                return new User();
            }

           
        }
    }
    private bool? _isMaster;

    /// <summary>
    /// 是否班主任
    /// </summary>
    protected bool IsMaster
    {
        get
        {
            if (!_isMaster.HasValue)
            {
                _isMaster = CurrentUser != null && CurrentUser.DepartmentUser.Count(o => o.Type == DepartmentUserType.班级班主任 && o.State < State.审核) > 0;
            }
            return _isMaster.Value;
        }
    }

    /// <summary>
    /// 获取权限
    /// 0：班主任
    /// 1: 老师
    /// 2：学生
    /// 3：注册用户
    /// </summary>
    /// <returns></returns>
    protected int GetAuth()
    {

        int auth = 0;

        try
        {

            var isCourse = db.new_ViewTaught.Where(o => o.UserId == CurrentUser.Id).ToList();

            switch (IsMaster)
            {
                case true:

                    if (isCourse.Count == 0)
                    {
                        auth = 5;//班主任不授课
                    }
                    else
                    {
                        auth = 0;
                    }

                    break;

                case false:


                    if (isCourse.Count == 0 && CurrentUser.Type < UserType.学生)
                    {
                        auth = 4;//老师不授课
                    }
                    else
                    {
                        auth = (int)CurrentUser.Type;
                    }
                    break;

                default:
                    break;
            }

            return auth;
        }

        catch (Exception)
        {

            var url = string.Format("{0}/SignOff?SsoRedirect={1}", base_url, Server.UrlEncode(string.Format("{0}/SignOn", base_url)));

            Response.Redirect(url, false);

            return auth;

        }
       

    }


    protected List<View_AlbumList> AlbumInit()
    {

        var ClassId = Guid.Parse(this.Session["class_id"].ToString());

       return  db.View_AlbumList.Where(o => o.ClassId == ClassId).ToList().OrderBy(o => o.CreateTime).ToList();

    }

    protected void GetNickName(string access_token, string openId)
    {

        var url = string.Format("https://api.weixin.qq.com/cgi-bin/user/info?access_token={0}&openid={1}", access_token, openId);
    

    }
    protected void VisitCheck(string code,string url)
    {
        WeiXin wx = new WeiXin();

        Session["GlobalOpenId"] = wx.GetOpenId(code);

        var GlobalOpenId = Session["GlobalOpenId"].ToString();

        var userOpen = db.UserOpen.Where(o => o.OpenId == GlobalOpenId).ToList();

        if (userOpen != null && userOpen.Count() == 1)
        {
            Guid userId = userOpen[0].UserId;

            var departmentUser = db.DepartmentUser.Where(o => o.UserId == userId).ToList();
            //不管是学生还是老师，学生的话只能有一个班

            this.Session["user_id"] = userId;

            switch (GetAuth())
            {
                case 0:
                case 5:
                    
                    var banDs = db.教师所在班级以及所教学科视图.Where(o => o.UserId == userId).Select(
                    o => new
                    {
                        Id = o.DepartmentId
                    }).ToList();

                    this.Session["class_id"] = banDs[0].Id;

                    break;
                case 1:
                    banDs = db.教师所在班级以及所教学科视图.Where(o => o.UserId == userId).Select(
                    o => new
                    {
                        Id = o.DepartmentId
       
                    }).ToList();

                    this.Session["class_id"] = banDs[0].Id;

                    break;
                case 2:

                    var stuDs = db.DepartmentUser.Where(o => o.UserId == userId && o.Type == DepartmentUserType.班级学生 && (o.State < State.审核 || o.State == State.历史)).ToList().Join(db.Department, o => o.DepartmentId, x => x.Id, (o, x) => new
                    {
                        Id = string.Format("{0}", o.DepartmentId),

                        Name = o.Department.DepartmentParent.Name + x.Name

                    }).OrderBy(o => o.Name).ToList();

                    this.Session["class_id"] = stuDs[0].Id;

                    break;

                default:

                    return;
            }
            
        }
        else
        {
            url = weixin_url + "WeiXinLogin.aspx?code=" + code;

        }
        Response.Redirect(url);
    }


    protected string Title = System.Configuration.ConfigurationManager.AppSettings["Title"].ToString();

    protected Guid UserId
    {
        get 
        {
            
            return Guid.Parse(this.Session["user_id"].ToString());
        
        }
    }
    protected string GetPlayerImg(string src)
    {

        if (src == null || src.Equals(string.Empty))
        {
            return string.Empty;
        }
        else
        {
            return "img/video.png";
        }

    }
    protected Guid ClassId
    {
        get
        {
            return Guid.Parse(this.Session["class_id"].ToString());

        }
    }

    protected Model model = new Model();

    /// <summary>
    /// 根据当前登录用户获取所在校区的所有年级
    /// </summary>
    /// <returns></returns>
    public Object FindAges() {

        Guid class_id = Guid.Parse(Session["class_id"].ToString());

        var classType = Convert.ToInt32(db.Department.Where(o => o.Id == class_id).ToList().Join(db.Department, o => o.TopId, x => x.Id, (o, x) => new
        {

            type = x.ClassType

        }).Select(o => new {
            classType = o.type
        }).First().classType);

        var catelog = db.Catalog.Where(o => (new CatalogType[] { CatalogType.年级_幼儿园, CatalogType.年级_小学, CatalogType.年级_初中, CatalogType.年级_高中, CatalogType.年级_其他 }.Contains(o.Type)) && o.State < State.审核).ToList();

        switch (classType)
        {
            case 1:
                return catelog.Where(o => new CatalogType[] { CatalogType.年级_小学, CatalogType.年级_初中, CatalogType.年级_其他 }.Contains(o.Type)).Select(o => new
                    {
                        Name =  o.Name,
                        Id = o.Id

                    }).ToList();

            case 2:
                return catelog.Where(o => o.Type == CatalogType.年级_幼儿园 || o.Type == CatalogType.年级_其他).Select(o => new
                {
                    Name = o.Name,
                    Id = o.Id

                }).ToList();

            case 3:
                return catelog.Where(o => o.Type == CatalogType.年级_小学 || o.Type == CatalogType.年级_其他).Select(o => new
                {
                    Name = o.Name,
                    Id = o.Id

                }).ToList();
            case 4:
                return catelog.Where(o => o.Type == CatalogType.年级_小学 || o.Type == CatalogType.年级_其他).ToList().Select(o => new
                {
                    Id = o.Id,
                    Name = o.Name
                    //Name = o.Name.Equals("七年级")?

                    //"初一":o.Name.Equals("八年级")?

                    //"初二":"初三"

                }).ToList();
            case 6:
                return catelog.Where(o => o.Type == CatalogType.年级_高中 || o.Type == CatalogType.年级_其他).ToList().Select(o => new
                {
                    Id = o.Id,
                    Name = o.Name
                    //Name = o.Name.Equals("七年级")?

                    //"初一":o.Name.Equals("八年级")?

                    //"初二":"初三"

                }).ToList();
            default:
                return catelog.Select(o => new
                {
                    Name = o.Name,
                    Id = o.Id

                }).ToList();
        }
    }

    public string GetResourceUrl(string key)
    {

        return string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings[key]) ? "#" : System.Configuration.ConfigurationManager.AppSettings[key];

    }
    protected List<View_ContentResource> GetResource(Guid id)
    {

        DataTable dt = new DataTable();

        var content_resource_list = db.View_ContentResource.Where(o => o.ContentId == id).ToList();

        return content_resource_list;

    }

    protected string GetRequestUrl(int type, string resource_id)
    {

        string boot_url = GetResourceUrl("ResourceUrl");

        string final_url = string.Empty;

        switch (type)
        {

            case 1: final_url = boot_url + "/ClassViewVideo.aspx?Id=" + resource_id + ""; break;

            case 2: final_url = boot_url + "/ClassViewPlain.aspx?Id=" + resource_id + ""; break;

            default:
                break;
        }
        return final_url;
    }
    /// <summary>
    /// 检测名字中是否含有复姓
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    protected bool surname_check(string str)
    {

        string[] SurnName = new string[]{"欧阳","太史","端木","上官","司马","东方","独孤","南宫","万俟","闻人","夏侯","诸葛","尉迟","公羊","赫连","澹台","皇甫","宗政","濮阳","公冶","太叔","申屠","公孙","慕容","仲孙","钟离","长孙","宇文","司徒","鲜于","司空","闾丘","子车","亓官","司寇","巫马","公西","颛孙","壤驷","公良","漆雕","乐正","宰父",  
"谷梁","拓跋","夹谷","轩辕","令狐","段干","百里","呼延","东郭","南门","羊舌","微生","公户","公玉","公仪","梁丘","公仲","公上","公门","公山","公坚","左丘","公伯","西门","公祖","第五","公乘","贯丘","公皙","南荣","东里","东宫","仲长","子书","子桑","即墨","达奚","褚师"};

        foreach (var item in SurnName)
        {
            if (str.Equals(item))
            {
                return true;
            }
        }

        return false;

    }
}