﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;
using System.Security.Principal;
using Homory.Model;
using System.Configuration;
using System.Web.Configuration;


/// <summary>
/// BaseControl 的摘要说明
/// </summary>
public class BaseControl : System.Web.UI.UserControl
{
    protected Global global = new Global();

    protected Entities pe = new Entities();

    protected Model model = new Model();

    protected string[] Grades = new string[] { "一", "二", "三", "四", "五", "六" };


    private int? __year;

    protected int __Year
    {
        get
        {
            if (!__year.HasValue)
            {
                __year = int.Parse(pe.Dictionary.Single(o => o.Key == "SchoolYear").Value);
            }
            return __year.Value;
        }
        set
        {
            __year = value;
        }
    }





    protected string base_url = System.Configuration.ConfigurationManager.AppSettings["SsoUrl"].ToString();

    public BaseControl()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }

    protected override void OnLoad(EventArgs e)
    {
       
        if (Session["user_id"] == null && string.IsNullOrEmpty(Request.QueryString["OnlineId"]))
        {
            SignOn();
            return;
        }
        else if(!string.IsNullOrEmpty(Request.QueryString["OnlineId"]))
        {
            var onlineId = Guid.Parse(Request.QueryString["OnlineId"]);
            var uid = pe.UserOnline.First(o => o.Id == onlineId).UserId;
            Session["user_id"] = uid.ToString();
            GenericIdentity i = new GenericIdentity(uid.ToString());
            GenericPrincipal p = new GenericPrincipal(i,null);
            HttpContext.Current.User = p;
        }

        base.OnLoad(e);
    }
    
    protected int GetYears(Department dept)
    {
        switch((int)dept.ClassType)
        {
            case 1:
                return 9;
            case 3:
                return 6;
            default:
                return 3;
        }
    //     九年一贯制 = 1,
    //    幼儿园 = 2,
    //    小学 = 3,
    //    初中 = 4,
    //    其他 = 5,
    //    无 = 0
    }


    /// <summary>
    /// 当前用户
    /// </summary>
    protected Homory.Model.User CurrentUser
    {
        get
        {
            var id = Guid.Parse(Session["user_id"].ToString());
            return pe.User.Single(o => o.Id == id);
        }
    }

    private Department _campus;

    /// <summary>
    /// 当前学校
    /// </summary>
    protected Department CurrentCampus
    {
        get
        {
            if (_campus != null) return _campus;
            var department = CurrentUser.DepartmentUser.FirstOrDefault(o => (o.Type == DepartmentUserType.借调后部门主职教师 || o.Type == DepartmentUserType.班级学生 || o.Type == DepartmentUserType.部门主职教师) && o.State < State.审核);
            if (department == null) return null;
            _campus = department.Department.DepartmentRoot;
            return _campus;
        }
    }

    private bool? _isMaster;

    /// <summary>
    /// 是否班主任
    /// </summary>
    protected bool IsMaster
    {
        get
        {
            if (!_isMaster.HasValue)
            {
                _isMaster = CurrentUser != null && CurrentUser.DepartmentUser.Count(o => o.Type == DepartmentUserType.班级班主任 && o.State < State.审核) > 0;
            }
            return _isMaster.Value;
        }
    }



    /// <summary>
    /// 是否是老师
    /// </summary>
    private bool? _isTearcher;
    protected bool IsTearcher
    {
        get 
        {
            if (!_isTearcher.HasValue)
            {
                _isTearcher = CurrentUser != null && CurrentUser.Type == UserType.教师;
            }
            return _isTearcher.Value;
        
        }
    
    }

    private bool? _isRegister;
    protected bool IsRegister
    {
        get
        {
            if (!_isRegister.HasValue)
            {
                _isRegister = CurrentUser != null && CurrentUser.Type == UserType.注册;
            }
            return _isRegister.Value;

        }

    }
    /// <summary>
    /// 获取权限
    /// 0：班主任
    /// 1: 老师
    /// 2：学生
    /// 3：注册用户
    /// </summary>
    /// <returns></returns>
    protected int GetAuth(){

        int auth = 0;

        var isCourse = pe.new_ViewTaught.Where(o => o.UserId == CurrentUser.Id).ToList();

        switch (IsMaster)
        {
            case true:

                if (isCourse.Count == 0 )
                {
                    auth = 5;//班主任不授课
                }
                else
                {
                    auth = 0;
                }

                break;

            case false:


                if (isCourse.Count == 0 && CurrentUser.Type < UserType.学生)
                {
                    auth = 4;//老师不授课
                }
                else
                {
                    auth = (int)CurrentUser.Type; 
                }
                break;

            default:
                break;
        }

        return auth;

    }

    protected void SignOn()
    {
        var path = Request.Url.AbsoluteUri;
        if (path.IndexOf('?') > 0)
            path = path.Substring(0, path.IndexOf('?'));
        var query = Request.QueryString.ToString();
        var url = string.Format("{0}/SignOn?SsoRedirect={1}{2}{3}",base_url, "" , Server.UrlEncode(path),
            string.IsNullOrWhiteSpace(query) ? string.Empty : "&", query);
        Response.Redirect(url, true);
    }

    protected void SignOff()
    {
        var url = string.Format("{0}/SignOff?SsoRedirect={1}", base_url, Server.UrlEncode(string.Format("{0}/SignOn", base_url)));
        Response.Redirect(url, false);
        Session.Clear();

    }

    protected int GradeCount(int classType)
    {
        switch (classType)
        {
            case 1:
                return 9;
            case 2:
                return 3;
            case 3:
                return 6;
            case 4:
                return 3;
            case 6:
                return 3;
            default:
                return 0;
        }
    }

    public static string[] J = { "初三", "初二", "初一" };
    public static string[] PJ = { "九年级", "八年级", "七年级", "六年级", "五年级", "四年级", "三年级", "二年级", "一年级" };
    public static string[] P = { "六年级", "五年级", "四年级", "三年级", "二年级", "一年级" };
    public static string[] S = { "高三", "高二", "高一" };
    public static string[] K = { "大班", "中班", "小班" };

    protected string GenGradeName(Department d)
    {
        int index = d.Ordinal - __Year - 1;
        var pdt = d.DepartmentRoot.ClassType;
        switch ((int)pdt)
        {
            case 1:
                return index < PJ.Length && index > -1 ? PJ[index] : string.Empty;
            case 4:
                return index < J.Length && index > -1 ? J[index] : string.Empty;
            case 3:
                return index < P.Length && index > -1 ? P[index] : string.Empty;
            case 2:
                return index < K.Length && index > -1 ? K[index] : string.Empty;
            case 6:
                return index < S.Length && index > -1 ? S[index] : string.Empty;
        }
        return string.Empty;
    }




    /// <summary>
    /// 检测名字中是否含有复姓
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    protected bool surname_check(string str)
    {

        string[] SurnName = new string[]{"欧阳","太史","端木","上官","司马","东方","独孤","南宫","万俟","闻人","夏侯","诸葛","尉迟","公羊","赫连","澹台","皇甫","宗政","濮阳","公冶","太叔","申屠","公孙","慕容","仲孙","钟离","长孙","宇文","司徒","鲜于","司空","闾丘","子车","亓官","司寇","巫马","公西","颛孙","壤驷","公良","漆雕","乐正","宰父",  
"谷梁","拓跋","夹谷","轩辕","令狐","段干","百里","呼延","东郭","南门","羊舌","微生","公户","公玉","公仪","梁丘","公仲","公上","公门","公山","公坚","左丘","公伯","西门","公祖","第五","公乘","贯丘","公皙","南荣","东里","东宫","仲长","子书","子桑","即墨","达奚","褚师"};

        foreach (var item in SurnName)
        {
            if (str.Equals(item))
            {
                return true;
            }
        }

        return false;

    }

    public string GetResourceUrl(string key)
    {

        return string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings[key]) ? "#" : System.Configuration.ConfigurationManager.AppSettings[key];

    }

    public static string CreateJsonParameters(DataTable dt)
    {
        /* /**************************************************************************** 
         * Without goingin to the depth of the functioning of this Method, i will try to give an overview 
         * As soon as this method gets a DataTable it starts to convert it into JSON String, 
         * it takes each row and in each row it grabs the cell name and its data. 
         * This kind of JSON is very usefull when developer have to have Column name of the . 
         * Values Can be Access on clien in this way. OBJ.HEAD[0].<ColumnName> 
         * NOTE: One negative point. by this method user will not be able to call any cell by its index. 
         * *************************************************************************/
        StringBuilder JsonString = new StringBuilder();
        //Exception Handling          
        if (dt != null && dt.Rows.Count > 0)
        {
            JsonString.Append("{ ");
            JsonString.Append("\"Head\":[ ");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                JsonString.Append("{ ");
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    if (j < dt.Columns.Count - 1)
                    {
                        JsonString.Append("\"" + dt.Columns[j].ColumnName.ToString() + "\":" + "\"" + dt.Rows[i][j].ToString() + "\",");
                    }
                    else if (j == dt.Columns.Count - 1)
                    {
                        JsonString.Append("\"" + dt.Columns[j].ColumnName.ToString() + "\":" + "\"" + dt.Rows[i][j].ToString() + "\"");
                    }
                }
                /*end Of String*/
                if (i == dt.Rows.Count - 1)
                {
                    JsonString.Append("} ");
                }
                else
                {
                    JsonString.Append("}, ");
                }
            }
            JsonString.Append("]}");
            return JsonString.ToString();
        }
        else
        {
            return null;
        }
    }
}