﻿/// <summary> 
///Access_token 的摘要说明 
/// </summary> 
public class Access_token
{
    public Access_token()
    {
        // 
        //TODO: 在此处添加构造函数逻辑 
        // 
    }
    string _access_token;
    string _expires_in;

    /// <summary> 
    /// 获取到的凭证  
    /// </summary> 
    public string access_token
    {
        get { return _access_token; }
        set { _access_token = value; }
    }

    /// <summary> 
    /// 凭证有效时间，单位：秒 
    /// </summary> 
    public string expires_in
    {
        get { return _expires_in; }
        set { _expires_in = value; }
    }
}
public class wxmessage
{
    public string FromUserName { get; set; }
    public string ToUserName { get; set; }
    public string MsgType { get; set; }
    public string EventName { get; set; }
    public string Content { get; set; }
    public string EventKey { get; set; }
}

public class OAuthClass
{
    public string access_token { get; set; }
    public string expires_in { get; set; }
    public string refresh_token { get; set; }
    public string openid { get; set; }
    public string scope { get; set; }
    public string unionid { get; set; }

}

public class UserInfo
{ 
    public string subscribe {get;set;}
    public string openid {get;set;}
    public string nickname {get;set;} 
    public string sex {get;set;}
    public string language {get;set;}
    public string city {get;set;}
    public string province {get;set;}
    public string country {get;set;}
    public string headimgurl {get;set;}
    public string subscribe_time {get;set;}
}

/**
   "subscribe": 1, 
    "openid": "o6_bmjrPTlm6_2sgVt7hMZOPfL2M", 
    "nickname": "Band", 
    "sex": 1, 
    "language": "zh_CN", 
    "city": "广州", 
    "province": "广东", 
    "country": "中国", 
    "headimgurl":    "http://wx.qlogo.cn/mmopen/g3MonUZtNHkdmzicIlibx6iaFqAc56vxLSUfpb6n5WKSYVY0ChQKkiaJSgQ1dZuTOgvLLrhJbERQQ4eMsv84eavHiaiceqxibJxCfHe/0", 
   "subscribe_time": 1382694957

 */