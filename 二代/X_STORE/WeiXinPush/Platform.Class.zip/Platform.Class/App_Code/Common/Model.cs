﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using JN.Framework.DBAccess;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Text;
using Homory.Model;

/// <summary>
/// Model 的摘要说明
/// </summary>
public class Model
{
	public Model()
	{

       
	}
    public Entities db = new Entities();
    /// <summary>
    /// 通过班级ID查询Content值
    /// </summary>
    /// <param name="class_id"></param>
    /// <returns></returns>
    public List<View_Content> FindContentByClassId(Guid class_id,int type ,int count, int zj_type,string text = "")
    {
         var page = 0;
         switch (zj_type)
        {
            case 0: page = count; break;

            case 1: page = (count / 5 + 1) * 5; break;

            default: page = count; break;
        }


        //string sql_string = string.Format(" SELECT * FROM dbo.View_Content WHERE ClassId = '{0}'", class_id.ToString());
        if(!string.IsNullOrEmpty(text))
        {
            return db.View_Content.Where(o => o.ClassId == class_id).ToList().Where(o => o.Content.Contains(text) && o.Type == type).OrderByDescending(o => o.DateTime).Take(page).ToList();
            //sql_string = string.Format(sql_string + " AND [Content] LIKE '%{0}%'", text);
        }
        else
        {
            return db.View_Content.Where(o => o.ClassId == class_id && o.Type == type).OrderByDescending(o => o.DateTime).Take(page).ToList();


        }
        //sql_string = sql_string + " AND Convert(varchar(10),DateTime) = Convert(varchar(10),getDate()) ORDER BY DateTime DESC";
        //SqlParameter[] sql_param = {
        //                                Database.MakeInParam("@sql_string",SqlDbType.NVarChar,250,sql_string)
        //                           };

        //Database.RunProc("ExecStored", sql_param, out dt);

        //return dt;
    }
    public List<View_Content> FindContentByClassId(Guid class_id, string text = "")
    {

        //string sql_string = string.Format(" SELECT * FROM dbo.View_Content WHERE ClassId = '{0}'", class_id.ToString());
        if (!string.IsNullOrEmpty(text))
        {
            return db.View_Content.Where(o => o.ClassId == class_id).ToList().Where(o => o.Content.Contains(text) && o.DateTime >= DateTime.Today).OrderBy(o => o.Type).ThenByDescending(o => o.DateTime).ToList();
            //sql_string = string.Format(sql_string + " AND [Content] LIKE '%{0}%'", text);
        }
        else
        {
            return db.View_Content.Where(o => o.ClassId == class_id && o.DateTime >= DateTime.Today).OrderBy(o => o.Type).ThenByDescending(o => o.DateTime).ToList();


        }
        //sql_string = sql_string + " AND Convert(varchar(10),DateTime) = Convert(varchar(10),getDate()) ORDER BY DateTime DESC";
        //SqlParameter[] sql_param = {
        //                                Database.MakeInParam("@sql_string",SqlDbType.NVarChar,250,sql_string)
        //                           };

        //Database.RunProc("ExecStored", sql_param, out dt);

        //return dt;
    }
    /// <summary>
    ///根据内容id获取评论信息
    /// </summary>
    /// <param name="content_id"></param>
    /// <returns></returns>
    public DataTable FindCommentByContentId(Guid content_id) {

        DataTable dt = null;

        //string sql_string = string.Format(
        //"with"
        //+" comment as"
        //+"("
        //    +" SELECT * FROM dbo.View_Comment WHERE ContentId = '{0}'"
        //    +" union all"
        //    +" select a.* from dbo.View_Comment a, dbo.View_Comment b"
        //                +" where a.Comment_ParentId = b.Comment_Id"
        //+")"
        //+" select * from comment"
        //, content_id.ToString());

        string sql_string = string.Format(
        " SELECT * FROM dbo.View_Comment WHERE ContentId = '{0}'"
        , content_id.ToString());



        SqlParameter[] sql_param = {
                                        Database.MakeInParam("@sql_string",SqlDbType.NVarChar,250,sql_string)
                                   };

        Database.RunProc("ExecStored", sql_param, out dt);

        return dt;

    }
    public DataTable FindPictureByAlbumId(Guid AlbumId) {

        DataTable dt = null;

        string queryStr = string.Format("select * from [dbo].[AlbumResource] where AlbumId = '{0}' and State < {1}", AlbumId.ToString(), Convert.ToInt32(State.审核));

        SqlParameter[] sql_param = {
                                        Database.MakeInParam("@sql_string",SqlDbType.NVarChar,2000,queryStr)
                                   };

        Database.RunProc("ExecStored", sql_param, out dt);

        return dt;

    }

    public DataTable TimeClassList(Guid ClassId)
    {
        DataTable DT = null;

        string queryStr = string.Format("select max(ar.CreateTime),max(ar.ThumbImgUrl) from [dbo].[Album] a"

        + "join [dbo].[AlbumResource] ar on a.AlbumId = ar.AlbumId"

        + "where a.ClassId == {0} group by Convert(nvarchar(10),ar.CreateTime,121)", ClassId.ToString());

        SqlParameter[] sql_param = {
                                        Database.MakeInParam("@sql_string",SqlDbType.NVarChar,2000,queryStr)
                                   };

        Database.RunProc("ExecStored", sql_param, out DT);

        return DT;
    
    }

    public DataTable FindStudentList(Guid ClassId) {

        DataTable DT = null;

        string queryStr = string.Format("SELECT up.OpenId,u.DisplayName AS sName,up.UserId,d.DisplayName AS cName FROM [dbo].[DepartmentUser] du INNER JOIN  [dbo].[UserOpen] up ON du.UserId = up.UserId" 
        
            +" INNER JOIN [dbo].[User] u ON u.Id = du.UserId And u.State<2"

            + " INNER JOIN [dbo].[Department] d ON d.Id = du.DepartmentId  And d.State<2" 

            +" WHERE du.DepartmentId = '{0}' and du.Type = {1}", ClassId.ToString(),1);

        SqlParameter[] sql_param = {
                                        Database.MakeInParam("@sql_string",SqlDbType.NVarChar,2000,queryStr)
                                   };

        Database.RunProc("ExecStored", sql_param, out DT);

        return DT;

    }
    public DataTable FindStudentUserId(Guid ClassId)
    {
        DataTable DT = null;

        string queryStr = string.Format("SELECT du.UserId FROM [dbo].[DepartmentUser] du "

            + " INNER JOIN [dbo].[User] u ON u.Id = du.UserId And u.State<2 and du.Type = 1"

            + " INNER JOIN [dbo].[Department] d ON d.Id = du.DepartmentId  And d.State<2"

            + " WHERE du.DepartmentId = '{0}'", ClassId.ToString());

        SqlParameter[] sql_param = {
                                        Database.MakeInParam("@sql_string",SqlDbType.NVarChar,2000,queryStr)
                                   };

        Database.RunProc("ExecStored", sql_param, out DT);

        return DT;

    
    }

    public DataTable FindContentUnReadList(Guid ContentId,Guid ClassId) {

        DataTable DT = null;

        string queryStr = string.Format("SELECT max(U.DisplayName) AS UserName,U.Id As UserId" 

                            +" FROM dbo.DepartmentUser D" 

                            +" INNER JOIN dbo.[User] U ON D.UserId = U.Id" 

                            +" WHERE U.Id NOT IN(SELECT C.UserId FROM dbo.C_Collect C WHERE C.isRead = 1 AND  C.ContentId = '{0}' )"

                            +" AND D.DepartmentId = '{1}' AND D.State <2 AND D.Type = 1"

                            +" GROUP BY U.Id", ContentId.ToString(), ClassId.ToString());

        SqlParameter[] sql_param = {
                                        Database.MakeInParam("@sql_string",SqlDbType.NVarChar,2000,queryStr)
                                   };

        Database.RunProc("ExecStored", sql_param, out DT);

        return DT;
    }

    public DataTable FindContentReadList(Guid ContentId)
    {

        DataTable DT = null;

        string queryStr = string.Format("SELECT U.DisplayName AS UserName,U.Id As UserId,(Convert(varchar(5),C.ReadTime,105)+' '+Convert(varchar(5),C.ReadTime,108) )As Time FROM  dbo.C_Collect C"

                         + " INNER JOIN dbo.[User] U ON C.UserId = U.Id"

                         + " AND C.isRead = 1"

                         + " WHERE C.ContentId = '{0}'"

                         + " AND U.State <2", ContentId.ToString());

        SqlParameter[] sql_param = {
                                        Database.MakeInParam("@sql_string",SqlDbType.NVarChar,2000,queryStr)
                                   };

        Database.RunProc("ExecStored", sql_param, out DT);

        return DT;
    }

    public List<View_ContentCollect> FindMyCollectContentByUserId(Guid user_id ,int type)
    {
        return db.View_ContentCollect.Where(o => o.UserId == user_id && o.isCollect == true && o.Type == type).ToList().OrderByDescending(o=>o.DateTime).ToList();
    }

    public string resplaceFace(string str)
    {

        string[] str_list = {"", "微笑", "撇嘴", "色", "发呆", "流泪", "暧昧", "闭嘴", "睡觉", "快哭了", "尴尬", "愤怒", "调皮", "呲牙", "惊讶", "难过", "冷汗", "折磨", "快吐了", "偷笑", "可爱", "白眼", "无奈", "饥饿", "困", "惊恐", "汗", "大笑", "大兵", "奋斗", "谩骂", "疑问", "安静", "眩晕", "抓狂", "衰"
                , "敲打", "再见", "擦汗", "不屑", "糗大了", "坏笑", "左哼哼", "右哼哼", "哈欠", "鄙视", "委屈", "快哭了", "奸笑", "亲亲", "雷到", "可怜", "抱抱", "晚上", "晴天", "炸弹", "骷髅","菜刀","猪头","西瓜","咖啡","米饭","爱心","强","弱","合作","胜利","佩服","勾引","搞定","挑衅","玫瑰","凋谢","吻","爱情","飞吻"};

        string tmpStr = Regex.Replace(str, @"\[([^\]]*)\]", (x) =>
        {
            string v = x.Groups[1].Value;
            for (var i = 0; i < str_list.Length; i++)
            {
                var s = str_list[i];
                if (s == v)
                {
                    v = string.Format("<img src = 'img/arclist/{0}.gif'/>", i);
                    break;
                }
            }
            return v;
        });

        return tmpStr;

    }

    public DataTable FindDayPicture(string Time) {

        DataTable DT = null;

        string queryStr = string.Format("select * from [dbo].[AlbumResource] ar"

        +" where Convert(nvarchar(10),ar.CreateTime,121) = '{0}' and ar.State < {1}",Time,Convert.ToInt32(State.审核));

        SqlParameter[] sql_param = {
                                        Database.MakeInParam("@sql_string",SqlDbType.NVarChar,2000,queryStr)
                                   };

        Database.RunProc("ExecStored", sql_param, out DT);

        return DT;

    
    }
    public static string CreateJsonParameters(DataTable dt)
    {
        /* /**************************************************************************** 
         * Without goingin to the depth of the functioning of this Method, i will try to give an overview 
         * As soon as this method gets a DataTable it starts to convert it into JSON String, 
         * it takes each row and in each row it grabs the cell name and its data. 
         * This kind of JSON is very usefull when developer have to have Column name of the . 
         * Values Can be Access on clien in this way. OBJ.HEAD[0].<ColumnName> 
         * NOTE: One negative point. by this method user will not be able to call any cell by its index. 
         * *************************************************************************/
        StringBuilder JsonString = new StringBuilder();
        //Exception Handling          
        if (dt != null && dt.Rows.Count > 0)
        {
            JsonString.Append("{ ");
            JsonString.Append("\"Head\":[ ");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                JsonString.Append("{ ");
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    if (j < dt.Columns.Count - 1)
                    {
                        JsonString.Append("\"" + dt.Columns[j].ColumnName.ToString() + "\":" + "\"" + dt.Rows[i][j].ToString() + "\",");
                    }
                    else if (j == dt.Columns.Count - 1)
                    {
                        JsonString.Append("\"" + dt.Columns[j].ColumnName.ToString() + "\":" + "\"" + dt.Rows[i][j].ToString() + "\"");
                    }
                }
                /*end Of String*/
                if (i == dt.Rows.Count - 1)
                {
                    JsonString.Append("} ");
                }
                else
                {
                    JsonString.Append("}, ");
                }
            }
            JsonString.Append("]}");
            return JsonString.ToString();
        }
        else
        {
            return string.Empty;
        }
    }
    public string ContentSubmit(HttpContext context,string[] picture_src_list,string[] suo_picture_src_list,string[] movie_src_list,string[] suo_movie_src_list,
        string[] adjunct_src_list,string[] adjunct_icon_list,string[] assistant_id_list,bool comment_flag,
        Guid user_id,Guid class_id, Guid course_id,int class_type,string content_value)
    {

        Entities db = new Entities();
       
        string title_value = string.Empty;

        string commentFlag = string.Empty;

        var time1 = Convert.ToDateTime(DateTime.Now.AddSeconds(-30).ToString("yyyy/MM/dd HH:mm:ss"));

        var content = db.C_content.Where(o => o.DateTime > time1 && o.Content == content_value).ToList();

        var json_result = string.Empty;

        if (content.Count > 0)
        {

            json_result = "{\"isRepeat\":\"true\"}";

            return json_result;
        }


        C_content content_object = new C_content();

        content_object.Id = Guid.NewGuid();

        content_object.Type = class_type;

        switch (comment_flag)
        {

            case true:
                commentFlag = "display:block";
                break;
            case false:
                commentFlag = "display:none";
                break;
            default:
                commentFlag = "display:block";
                break;
        }

        content_object.CommentFlag = commentFlag;

        content_object.State = 1;

        content_object.UserId = user_id;

        content_object.DateTime = DateTime.Now;

        content_object.ClassId = class_id;

        content_object.CourseId = course_id;

        content_object.Content = content_value;

        for (int i = 0; i < picture_src_list.Length; i++)
        {
            content_object.C_Adjunct.Add(new C_Adjunct
            {
                Id = Guid.NewGuid(),

                Url = picture_src_list[i],

                State = 1,

                ThumbImgUrl = suo_picture_src_list[i],

                Type = 1

            });
            if (class_type == 2)
            {
                db.AlbumResource.Add(

               new AlbumResource
               {

                   AlbumId = Guid.Empty,

                   PictureId = Guid.NewGuid(),

                   CreateTime = DateTime.Now,

                   CreateDate = DateTime.Now.Date,

                   PictureUrl = picture_src_list[i],

                   ThumbImgUrl = suo_picture_src_list[i],

                   PictureName = "班级活动" + i,

                   State = State.启用,

                   Remark = string.Empty

               });
            }


        };

        for (int j = 0; j < movie_src_list.Length; j++)
        {
            content_object.C_Adjunct.Add(new C_Adjunct
            {
                Id = Guid.NewGuid(),

                Url = movie_src_list[j],

                State = 1,

                ThumbImgUrl = suo_movie_src_list[j],

                Type = 2

            });

        }
        for (int k = 0; k < adjunct_src_list.Length; k++)
        {
            content_object.C_Adjunct.Add(new C_Adjunct
            {
                Id = Guid.NewGuid(),

                Url = adjunct_src_list[k],

                State = 1,

                ThumbImgUrl = adjunct_icon_list[k],

                Type = 3
            });
        }
        for (int l = 0; l < assistant_id_list.Length; l++)
        {
            if (string.Empty.Equals(assistant_id_list[l]))
            {
                break;
            }
            content_object.Content_Resource.Add(new Content_Resource
            {
                Id = Guid.NewGuid(),

                ResourceId = Guid.Parse(assistant_id_list[l].ToString()),

                State = 1,

                DateTime = DateTime.Now
            });
        }
        content_object.image = "废弃字段";

        db.C_content.Add(content_object);

        var dt = FindStudentList(class_id);

        var userList = string.Empty;

        var UserDT = FindStudentUserId(class_id);

        foreach (DataRow item in UserDT.Rows)
        {
            userList += item["UserId"].ToString() + "|";

        }


        if (dt.Rows.Count != 0)
        {

            json_result = Model.CreateJsonParameters(dt);

            var access_token = WeiXin.GetAccess_token().access_token;

            var course_name = db.Catalog.SingleOrDefault(o => o.Id == course_id).Name.ToString();

            User user = (User)context.Session["User"];

            foreach (DataRow DateRow in dt.Rows)
            {

                var userPush = new UserPush();

                userPush.Id = Guid.NewGuid();

                userPush.MessageId = content_object.Id;

                userPush.OpenId = DateRow["OpenId"].ToString();

                userPush.Push = false;

                switch (class_type)
                {

                    case 1:
                        userPush.Type = PushType.课堂作业; break;
                    case 2:
                        userPush.Type = PushType.班级活动; break;
                    default:
                        userPush.Type = PushType.班级活动; break;
                }

                userPush.UserId = user_id;

                db.UserPush.Add(userPush);
            }

            db.SaveChanges();

        


        }
        else
        {
            json_result = Model.CreateJsonParameters(UserDT);

            db.SaveChanges();
        }

        return json_result;

    }
}

public static class ModelExtension
{
    public static string FormatTimeShort(this DateTime time)
    {

       
        if (time.Date == DateTime.Today)
        {
            return time.ToString("HH:mm");
        }
        if ((DateTime.Today - time).TotalDays < 1)
            return "昨天";
        return (DateTime.Today - time).TotalDays < 2 ? "前天" : time.ToString("MM/dd");
    }

    

}