﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Global 的摘要说明
/// </summary>
public class Global
{
    public string user_id, user_name,class_id;

	public Global()
	{
        this.user_id = "用户ID";

        this.user_name = "用户名";

        this.class_id = "班级ID";
	}


}