﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Weather 的摘要说明
/// </summary>
public class Weather
{
    public string city { get; set; }//城市  
    public string temp1 { get; set; }//温度
    public string temp2 { get; set; }//温度
    public string temp3 { get; set; }//温度
    public string temp4 { get; set; }//温度
    public string night_temp1 { get; set; }//温度
    public string night_temp2 { get; set; }//温度
    public string night_temp3 { get; set; }//温度
    public string night_temp4 { get; set; }//温度
    public string figure1 { get; set; }//天气情况
    public string figure2 { get; set; }//天气情况
    public string figure3 { get; set; }
    public string figure4 { get; set; }
    public string night_figure1 { get; set; }//天气情况
    public string night_figure2 { get; set; }//天气情况
    public string night_figure3 { get; set; }
    public string night_figure4 { get; set; }
    public string week1 { get; set; }//星期
    public string week2 { get; set; }//星期
    public string week3 { get; set; }//星期
    public string week4 { get; set; }//星期

}
