﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

/// <summary>
/// BundleConfig 的摘要说明
/// </summary>
public class BundleConfig
{
    public static void RegisterBundles(BundleCollection bundles)
    {
        bundles.Add(new StyleBundle("~/bundles/style")
            .Include(
            "~/css/home_A.css",
            "~/css/bootstrap.min.css",
            "~/css/owl.carousel.min.css",
            "~/css/font-awesome.min.css",
            "~/css/style.css",
            "~/css/iscroll.css",
            "~/css/qqface.css",
            "~/Content/jquery.fancybox.css",
            "~/css/style-responsive.css",
            "~/Content/jquery.fancybox-buttons.css",
            "~/Content/jquery.fancybox-thumbs.css"
            ));
        bundles.Add(new ScriptBundle("~/bundles/script")
            .Include(
            "~/js/jquery.min.js",
            "~/js/skycons.js",
            "~/js/summernote.min.js",
            "~/js/bootstrap.min.js",
            "~/js/jquery.nicescroll.js",
            "~/js/jquery.backstretch.min.js",
            "~/js/jquery.qqFace.js",
            "~/js/apps.js",
            "~/js/owl.carousel.min.js",
            "~/Scripts/jquery.fancybox.pack.js",
            "~/Scripts/jquery.mousewheel-3.0.6.pack.js",
            "~/Scripts/jquery.fancybox-buttons.js",
            "~/Scripts/jquery.fancybox-thumbs.js",
            "~/Scripts/jquery.fancybox-media.js"
            ));
    }
}