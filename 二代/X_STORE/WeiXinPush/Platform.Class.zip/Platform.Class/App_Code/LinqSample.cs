﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// LinqSample 的摘要说明
/// </summary>
public class LinqSample
{
    public interface I学生费用
    {
        string 姓名 { get; set; }
        int 费用 { get; set; }
    }

    public interface I学生学号
    {
        string 姓名 { get; set; }
        string 学号 { get; set; }
    }


    public class 学生费用 : I学生费用
    {
        public string 姓名 { get; set; }
        public int 费用 { get; set; }
    }

    public class 学生学号 : I学生学号
    {
        public string 姓名 { get; set; }
        public string 学号 { get; set; }
    }

    public class 学生 : 学生费用, I学生学号
    {
        public string 学号 { get; set; }

        public 学生() { }

        public 学生(学生费用 a, I学生学号 b)
        {
            this.姓名 = a.姓名;
            this.费用 = a.费用;
            this.学号 = b.学号;
        }
    }

    public void Do()
    {
        var list = new List<学生费用>();
        list.Add(new 学生费用 { 姓名 = "李佳", 费用 = 20 });
        list.Add(new 学生费用 { 姓名 = "李佳", 费用 = 5 });
        list.Add(new 学生费用 { 姓名 = "张二猛", 费用 = 1 });
        list.Add(new 学生费用 { 姓名 = "张二猛", 费用 = 2 });
        list.Add(new 学生费用 { 姓名 = "张二猛", 费用 = 3 });

        var listX = new List<学生学号>();
        listX.Add(new 学生学号 { 姓名 = "李佳", 学号 = "A" });
        listX.Add(new 学生学号 { 姓名 = "张二猛", 学号 = "B" });


        var output = new List<学生费用>();
        var result = list.GroupBy(o => o.姓名);
        foreach(var group in result)
        {
            output.Add(new 学生费用 { 姓名 = group.Key, 费用 = group.Sum(o => o.费用) });
        }

        var final = output.Join(listX, a => a.姓名, b => b.姓名, (a, b) => new 学生(a, b));
    }

    public void Do2()
    {
        var list = new List<学生费用>();
        list.Add(new 学生费用 { 姓名 = "李佳", 费用 = 20 });
        list.Add(new 学生费用 { 姓名 = "李佳", 费用 = 5 });
        list.Add(new 学生费用 { 姓名 = "张二猛", 费用 = 1 });
        list.Add(new 学生费用 { 姓名 = "张二猛", 费用 = 2 });
        list.Add(new 学生费用 { 姓名 = "张二猛", 费用 = 3 });

        var listX = new List<学生学号>();
        listX.Add(new 学生学号 { 姓名 = "李佳", 学号 = "A" });
        listX.Add(new 学生学号 { 姓名 = "张二猛", 学号 = "B" });

        var final = listX.GroupJoin(list, b => b.姓名, a => a.姓名, (b, a) => new 学生 { 姓名 = b.姓名, 学号 = b.学号, 费用 = a.Sum(o => o.费用) });
    }


}
