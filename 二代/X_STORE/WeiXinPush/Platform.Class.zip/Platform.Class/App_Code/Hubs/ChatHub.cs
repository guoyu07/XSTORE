﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using Telerik.Web.UI;
using Newtonsoft.Json;
using Homory.Model;

[HubName("chatHub")]
public class ChatHub : Hub
{
    protected Entities db = new Entities();

    //protected Dictionary<string, string> _dict;

    protected int GetPacketCount(string userId)
    {
        var UserId = Guid.Parse(userId);

        return db.C_call.Where(o => o.ReceiverID == UserId && o.State < State.审核 && o.isRead == false).ToList().Count();

    }

    public void sendMessage(string userIdStr)
    {

        var content = userIdStr.Split(new[]{'|'}, StringSplitOptions.RemoveEmptyEntries).Select(o => new { Count = GetPacketCount(o), UserId = o }).ToList();

        Clients.All.broadcastMessage(content);

    }

    public void refreshPaceket(string userIdStr) {

        Clients.All.refreshPacketMessage(userIdStr);
    }
        
    public void refreshContent(string userIdStr)
    {

        Clients.All.refreshMessage(userIdStr);

    }
    //public override System.Threading.Tasks.Task OnConnected()
    //{
    //    var key = Context.ConnectionId;
    //    var userId = "AE16E587-8C04-4C77-8E5A-08D252985635";
    //    if (!_dict.ContainsKey(key))
    //        _dict.Add(key, userId);
    //    return base.OnConnected();
    //}

    //public override System.Threading.Tasks.Task OnDisconnected(bool stopCalled)
    //{
    //    var key = Context.ConnectionId;
    //    if (_dict.ContainsKey(key))
    //        _dict.Remove(key);
    //    return base.OnDisconnected(stopCalled);
    //}

    //public override System.Threading.Tasks.Task OnReconnected()
    //{
    //    var key = Context.ConnectionId;
    //    var userId = "AE16E587-8C04-4C77-8E5A-08D252985635";
    //    if (!_dict.ContainsKey(key))
    //        _dict.Add(key, userId);
    //    return base.OnReconnected();
    //}
}
