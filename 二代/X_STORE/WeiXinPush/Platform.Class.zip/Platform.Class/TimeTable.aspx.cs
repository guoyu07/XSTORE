﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Homory.Model;

public partial class TimeTable : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            var code = HttpContext.Current.Request.QueryString["code"];

            if (code != null)
            {
                var url = weixin_url + "TimeTable.aspx";

                VisitCheck(code, url);
            }
            PageInit();
        }
    }

    private void PageInit() {

        Guid class_id = Guid.Parse(this.Session["class_id"].ToString());

        C_site_config csc = db.C_site_config.SingleOrDefault(o => o.ClassId == class_id);

        if (csc!=null && csc.Kcontent != null && !string.Empty.Equals(csc.Kcontent))
        {
            var timetable_list = csc.Kcontent.Split(new char[] { ',' });

            var class_timetable_label_list = class_timetable_P.Controls.OfType<Label>().Select(o => o).ToList();

            for (int i = 0; i < timetable_list.Count(); i++)
            {
                class_timetable_label_list[i].Text = timetable_list[i];
            }
        }
    }
}