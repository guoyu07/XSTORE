﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EntityFramework.Extensions;
using System.Data;
using Homory.Model;

public partial class OutboxPacket : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageInit();
        }
    }
    protected void PageInit(int index = 1,int type = 1)
    {
        //switch (GetAuth())
        //{

        //    case 2:
        //        this.sendPacketDiv.Visible = false;
        //        break;
        //    default:
        //        this.sendPacketDiv.Visible = true;
        //        break;
        //}


        var rp = db.C_call.Where(o => o.UserId == UserId && o.State < State.审核).OrderByDescending(o => o.Datetime).ToList().GroupBy(o => o.TopId).ToList();

        List<C_call> packet_source = new List<C_call>();

        foreach (var item in rp)
        {
            packet_source.Add(item.OrderByDescending(o => o.Datetime).FirstOrDefault());
        }

        var packet_source_obj = packet_source.Select
                                            (
                                            s =>
                                            new
                                            {
                                                ReceiveName = s.User1.RealName,
                                                Id = s.Id,
                                                Message = s.ParentId == null ? s.Message : "回复:" + s.Message,
                                                Datetime = s.Datetime,
                                                ParentId = s.ParentId,
                                                isRead = s.isRead
                                            }).ToList();


        this.paging_div.Visible = packet_source_obj.Count() > 0 ? true : false;

        var page_size = 10;

        this.page_repeater.DataSource = pagingInit(index, packet_source_obj.Count(), page_size);

        this.page_repeater.DataBind();

        if (type == 1)
        {
            this.receive_packet_P.DataSource = packet_source_obj.Skip((index - 1 )* page_size).Take(page_size).ToList();

            this.receive_packet_P.DataBind();
        }

    }

    protected DataTable pagingInit(int index, int total,int page_size)
    {
        var page_index = 0;

        var total_page = 0;

        var show_page_count = 0;

        DataTable page_dt = new DataTable();

        total_page = (total + page_size - 1) / page_size;

        show_page_count = ((total_page + page_size - 1) / page_size == (index + page_size - 1) / page_size) ? total_page + 1 : ((index + page_size - 1) / page_size) * page_size + 1;

        page_index = (index / page_size + index % page_size) > 1 ? (((index + page_size - 1) / page_size-1) * page_size+1) : 1;

        page_dt.Columns.Add("class", typeof(string));
        page_dt.Columns.Add("index", typeof(int));
        page_dt.Columns.Add("info", typeof(string));
        page_dt.Columns.Add("click", typeof(string));

        DataRow dr = page_dt.NewRow();

        dr["class"] = "";
        dr["info"] = "&laquo;";
        dr["index"] = (index / page_size) <= 1 ? 1 : (index / page_size - 1) * page_size + 1;
        dr["click"] = "left_ten_click(this)";

        page_dt.Rows.Add(dr);

        dr = page_dt.NewRow();

        dr["class"] = "";
        dr["info"] = "&lsaquo;";
        dr["index"] = (index + page_size - 1) / page_size <= 1 ? 1 : index - 1;
        dr["click"] = "page_click(this)";

        page_dt.Rows.Add(dr);

        for (int i = page_index; i < show_page_count; i++)
        {
            //如果当前页为点击页，泽将class设置为active
            dr = page_dt.NewRow();

            if (i == index)
            {

                dr["class"] = "active";

            }
            else
            {

                dr["class"] = "";

            }

            dr["info"] = i.ToString();
            dr["index"] = i;
            dr["click"] = "page_click(this)";

            page_dt.Rows.Add(dr);

        }

        dr = page_dt.NewRow();

        dr["class"] = "";
        dr["info"] = "&rsaquo;";
        dr["index"] = index == total_page ? index : (index + 1);
        dr["click"] = "page_click(this)";

        page_dt.Rows.Add(dr);

        dr = page_dt.NewRow();

        dr["class"] = "";
        dr["info"] = "&raquo;";
        dr["index"] = (index + page_size) > total_page ? (index / page_size) * page_size + 1 : (index / page_size + 1) * page_size + 1;
        dr["click"] = "right_ten_click(this)";

        page_dt.Rows.Add(dr);

        return page_dt;
    
    }
    //protected void pagingInit()
    //{ 
        
    //}
    protected string IsRead(bool isRead)
    {
        switch (isRead)
        {
            case false: return "favorite fa fa-star";
            case true: return "favorite fa fa-star text-warning";
            default: return "favorite fa fa-star";
        }
    }
    protected void show_message_AjaxRequest(object sender, Telerik.Web.UI.AjaxRequestEventArgs e)
    {
        Guid packet_id = Guid.Parse(e.Argument.ToString());

        Guid Top_id = (Guid)db.C_call.SingleOrDefault(o => o.Id == packet_id).TopId;

        this.message_RTV.DataSource = db.C_call.Where(o => o.State < State.审核 && o.TopId == Top_id).ToList().OrderBy(o => o.Datetime).Select
         (
             o => new

             {
                 ParentId = o.ParentId,

                 Id = o.Id,

                 UserName = o.User.RealName,

                 Message = o.Message,

                 Time = o.Datetime
             }
         );

        this.message_RTV.DataBind();

        this.message_RTV.ExpandAllNodes();
    }
    protected void packet_P_AjaxRequest(object sender, Telerik.Web.UI.AjaxRequestEventArgs e)
    {

        string[] data = e.Argument.ToString().Split('|');

        PageInit(Convert.ToInt32(data[0]), Convert.ToInt32(data[1]));

    }
}