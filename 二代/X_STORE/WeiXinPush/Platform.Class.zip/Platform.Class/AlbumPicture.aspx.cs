﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Homory.Model;

public partial class AlbumPicture : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            var type = Convert.ToInt32(Request.QueryString["Type"].ToString());

            switch (type)
            {
                case 0:
                    PageInit();
                    break;
                case 1:
                    _PageInit();
                    break;
                default:
                    break;
            }

           
        }
    }
    protected void _PageInit() {

        var PictureId = Guid.Parse(Request.QueryString["PictureId"].ToString());

        var ClassId = Guid.Parse(this.Session["class_id"].ToString());

        var AlbumName = Convert.ToDateTime(db.AlbumResource.SingleOrDefault(o => o.PictureId == PictureId).CreateTime).ToString("yyyy-MM-dd");

        this.headTitle.InnerText = AlbumName;

        this.aTitle.InnerHtml = AlbumName;

        this.PictureRepeater.DataSource = model.FindDayPicture(AlbumName);

        this.PictureRepeater.DataBind();

        this.AlbumRepeater.DataSource = db.View_AlbumList.Where(o => o.ClassId == ClassId).ToList().OrderBy(o => o.CreateTime);

        this.AlbumRepeater.DataBind();
    }
    protected string Display() { 
    
        if (GetAuth() == 0 || GetAuth() == 5)
	    {
            return "display:block";
	    }
        else
        {
            return "display:none";
        }
    }

    protected Album AlbumObj {

        get {

            var type = Convert.ToInt32(Request.QueryString["Type"].ToString());

            if (type == 0)
            {
                var AlbumId = Guid.Parse(Request.QueryString["AlbumId"].ToString());

                return db.Album.SingleOrDefault(o => o.AlbumId == AlbumId);
            }
            else
            {
                Album album = new Album();

                var PictureId = Guid.Parse(Request.QueryString["PictureId"].ToString());

                var AlbumName = Convert.ToDateTime(db.AlbumResource.SingleOrDefault(o => o.PictureId == PictureId).CreateTime).ToString("yyyy-MM-dd");

                album.DefaultUrl = db.AlbumResource.SingleOrDefault(o => o.PictureId == PictureId).PictureUrl;

                album.AlbumName = AlbumName;

                album.Remark = "当天的图片";

                return album;
            }   
        }
    }

    protected void PageInit()
    {
        var ClassId = Guid.Parse(this.Session["class_id"].ToString());

        var AlbumId = Guid.Parse(Request.QueryString["AlbumId"].ToString());

        var AlbumName = Request.QueryString["AlbumName"].ToString();

        this.headTitle.InnerText = AlbumName;

        this.aTitle.InnerHtml = AlbumName;

        this.AlbumId.Text = AlbumId.ToString();

        this.PictureRepeater.DataSource = db.AlbumResource.Where(o => o.AlbumId == AlbumId && o.State < State.审核).ToList();

        this.PictureRepeater.DataBind();

        this.AlbumRepeater.DataSource =  db.View_AlbumList.Where(o => o.ClassId == ClassId).ToList().OrderBy(o => o.CreateTime);

        this.AlbumRepeater.DataBind();
    }
    protected void AlbumUploadRap_AjaxRequest(object sender, Telerik.Web.UI.AjaxRequestEventArgs e)
    {

        if (Convert.ToInt32(Request.QueryString["Type"].ToString()) == 0)
        {
            PageInit();
        }
        else
        {
            _PageInit();
        }
        AlbumUploadRap.ResponseScripts.Add("autosize();");
    }

    protected string InitShow() {

        var type = Convert.ToInt32(Request.QueryString["Type"].ToString());

        if (type == 1)
        {
            return string.Empty;
        }

        var AlbumId = Guid.Parse(this.AlbumId.Text);

        var PictureObjList = db.AlbumResource.Where(o=>o.AlbumId == AlbumId && o.State < State.审核).ToList();

        if (PictureObjList == null || PictureObjList.Count()==0)
	    {

            return "display:none";

	    }
        else
	    {
            return string.Empty;
	    }

        
    
    }
    protected string HiddenFunction()
    {
        var type = Convert.ToInt32(Request.QueryString["Type"].ToString());

        if (type == 1)
        {
            return "display:none";
        }
        else
        {
            return string.Empty;
        }

    }
    protected string TitleShow()
    {

        var type = Convert.ToInt32(Request.QueryString["Type"].ToString());

        if (type == 1)
        {
            return "display:none";
        }

        var AlbumId = Guid.Parse(this.AlbumId.Text);

        var PictureObjList = db.AlbumResource.Where(o => o.AlbumId == AlbumId && o.State < State.审核).ToList();

        if (PictureObjList == null || PictureObjList.Count() == 0)
        {

            return string.Empty;

        }
        else
        {
            return  "display:none";
        }

    }
}