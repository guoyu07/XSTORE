﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace Web.code.helper
{
    public class DBHelper 
    {
        private SqlConnection connection;
        static string connectionString = ConfigurationManager.AppSettings["ConnectionString"];
        public SqlConnection Connection
        {
            get
            {
                try
                {
                    if (connection == null)
                    {
                        connection = new SqlConnection(connectionString);
                        connection.Open();
                    }
                    else if (connection.State == System.Data.ConnectionState.Closed)
                    {
                        connection.Open();
                    }
                    else if (connection.State == System.Data.ConnectionState.Broken)
                    {
                        connection.Close();
                        connection.Open();
                    }
                }
                catch (Exception e)
                {
                    connection.Dispose();
                    connection.Close();
                    connection = new SqlConnection(connectionString);
                    connection.Open();
                }
                return connection;
            }
        }

        public bool executeSQL(string sql, params SqlParameter[] p)
        {
            bool bol = false;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    //判断是否有参数，并给sql语句中的参数赋值
                    if (p != null && p.Length != 0)
                        cmd.Parameters.AddRange(p);
                    bol = cmd.ExecuteNonQuery() > 0 ? true : false;
                }
                con.Close();
            }
            return bol;
        }

        /// <summary>
        /// 根据SQL语句(带参)返回一个数据表
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public DataTable GetDataSet(string sql, params SqlParameter[] values)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    con.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddRange(values);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                }
                con.Close();
            }
            return ds.Tables[0];
        }

        public object GetSingle(string SQLString, params SqlParameter[] cmdParms)
        {
            object obj = null;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQLString, con))
                {
                    con.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddRange(cmdParms);
                    try
                    {
                        obj = cmd.ExecuteScalar();
                        cmd.Parameters.Clear();
                    }
                    catch (System.Data.SqlClient.SqlException e)
                    {
                        throw e;
                    }
                }
                con.Close();
            }
            return obj;
        }
    }
}