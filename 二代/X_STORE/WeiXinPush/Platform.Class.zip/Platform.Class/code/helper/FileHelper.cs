﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Web.code.helper
{

    /// <summary>
    /// 文件操作帮助类
    /// </summary>
    public class FileHelper
    {
        /// <summary>
        /// 判断文件夹是否存在并创建
        /// </summary>
        /// <param name="str_path"></param>
        public static void ExistsFolder(string str_path)
        {
            if (!Directory.Exists(str_path))
                Directory.CreateDirectory(str_path);
        }
        ///   <summary> 
        ///   检查上传的是否为图片 
        ///   </summary> 
        ///   <param name= "str_MIME"> 文件MIME类型 </param> 
        ///   <returns> 如果扩展名有效,返回true,否则返回false. </returns> 
        public static bool CheckValidExt(string str_MIME)
        {
            string AllowMIME = @"image/gif|image/jpeg|image/pjpeg|image/bmp|application/x-jpg|application/x-bmp
                                |application/bmp|image/png|image/x-png|application/octet-stream";//所有的图片类型
            bool flag = false;
            string[] aExt = AllowMIME.Split('|');
            foreach (string filetype in aExt)
            {
                if (filetype.ToLower() == str_MIME)
                {
                    flag = true;
                    break;
                }
            }
            return flag;
        }
        /// <summary> 
        /// 取得文件后缀 
        /// </summary> 
        /// <param name="filename">文件名称</param> 
        /// <returns></returns> 
        public static string GetFileExtends(string filename)
        {
            string ext = null;
            if (filename.IndexOf('.') > 0)
            {
                string[] fs = filename.Split('.');
                ext = fs[fs.Length - 1];
            }
            return ext;
        }

        /// <summary>
        /// 生成一个上传的文件名称
        /// </summary>
        /// <param name="hz">后缀，要带点:.jpg</param>
        /// <returns></returns>
        public static string GetUploadFileName(string hz) 
        {
            string datetime = DateTime.Now.ToString("yyyyMMddhhmmss");
            Random rnd = new Random();
            int i_n = rnd.Next(1000, 9999);
            string str_fileName = datetime + i_n.ToString() + hz;
            return str_fileName;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="minwidth">微缩图要设置的宽度</param>
        /// <param name="minheight">微缩图要设置的长度</param>
        /// <param name="forwidth">原图宽度</param>
        /// <param name="forheight">原图长度</param>
        /// <returns></returns>
        public static System.Drawing.Size NewSize(int minwidth, int minheight, int forwidth, int forheight)
        {
            int newwidth;
            int newheight;
            if (forwidth > forheight)
            {
                newwidth = minwidth;
                newheight = newwidth * forheight / forwidth;
            }
            else
            {
                newheight = minheight;
                newwidth = newheight * forwidth / forheight;
            }
            System.Drawing.Size _Size = new Size();
            _Size.Height = newheight;
            _Size.Width = newwidth;
            return _Size;
        }
        /// <summary>
        /// 火狐下保存图片
        /// </summary>
        /// <param name="stream">文件流</param>
        /// <param name="FilePath">上传到服务器上的哪个文件夹全路径</param>
        /// <param name="filename">文件名称带后缀</param>
        /// <returns>是否上传成功</returns>
        public static bool SendToImage(Stream stream, string FilePath, string filename)
        {
            bool flag = false;
            try
            {
                System.Drawing.Image img = System.Drawing.Image.FromStream(stream);
                int lenEnd = filename.LastIndexOf('.');
                string fileType = ".jpg";
                fileType = filename.Substring(lenEnd);
                ImageFormat imgformat = img.RawFormat;
                int width = img.Width;
                int height = img.Height;

                Size newSize = NewSize(width, height, img.Width, img.Height);

                Bitmap bm = new Bitmap(newSize.Width, newSize.Height);
                Graphics g = Graphics.FromImage(bm);

                // 设置画布的描绘质量
                g.CompositingQuality = CompositingQuality.HighQuality;
                g.SmoothingMode = SmoothingMode.HighQuality;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;

                g.DrawImage(img, new Rectangle(0, 0, newSize.Width, newSize.Height), 0, 0, img.Width, img.Height, GraphicsUnit.Pixel);
                g.Dispose();

                // 以下代码为保存图片时，设置压缩质量
                EncoderParameters encoderParams = new EncoderParameters();
                long[] quality = new long[1];
                quality[0] = 100;

                EncoderParameter encoderParam = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
                encoderParams.Param[0] = encoderParam;

                //获得包含有关内置图像编码解码器的信息的ImageCodecInfo 对象。
                ImageCodecInfo[] arrayICI = ImageCodecInfo.GetImageEncoders();
                ImageCodecInfo jpegICI = null;
                ImageCodecInfo GIFICI = null;
                ImageCodecInfo jpgICI = null;
                ImageCodecInfo pngICI = null;
                ImageCodecInfo bmpICI = null;

                ImageCodecInfo allICI = null;
                for (int x = 0; x < arrayICI.Length; x++)
                {
                    if (arrayICI[x].FormatDescription.Equals("JPEG"))
                        jpegICI = arrayICI[x];//设置JPEG编码

                    if (arrayICI[x].FormatDescription.Equals("GIF"))
                        GIFICI = arrayICI[x];//设置GIF编码

                    if (arrayICI[x].FormatDescription.Equals("JPG"))
                        jpgICI = arrayICI[x];//设置GIF编码

                    if (arrayICI[x].FormatDescription.Equals("PNG"))
                        pngICI = arrayICI[x];//设置GIF编码

                    if (arrayICI[x].FormatDescription.Equals("BMP"))
                        bmpICI = arrayICI[x];//设置GIF编码

                }

                string stringpath = null;
                string imagename = filename;
                if (fileType == ".jpg")
                {
                    stringpath = FilePath + "/" + imagename;
                    allICI = jpegICI;
                }
                else if (fileType == ".gif")
                {
                    stringpath = FilePath + "/" + imagename;
                    allICI = GIFICI;
                }
                else if (fileType == ".jpg")
                {
                    stringpath = FilePath + "/" + imagename;
                    allICI = jpgICI;
                }
                else if (fileType == ".png")
                {
                    stringpath = FilePath + "/" + imagename;
                    allICI = pngICI;
                }
                else
                {
                    stringpath = FilePath + "/" + imagename;
                    allICI = bmpICI;
                }

                try
                {
                    MemoryStream ms = new MemoryStream();
                    bm.Save(ms, ImageFormat.Jpeg);// 保存文件流
                    ms.Close();
                    bm.Save(stringpath, allICI, encoderParams); // 保存到文件
                    flag = true;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    img.Dispose();
                    bm.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return flag;
        }
        //// <summary>
        /// 删除文件文件或图片
        /// </summary>
        /// <param name="path">当前文件的路径</param>
        /// <returns>是否删除成功</returns>
        public static bool FilePicDelete(string path)
        {
            bool ret = false;
            System.IO.FileInfo file = new System.IO.FileInfo(path);
            if (file.Exists)
            {
                file.Delete();
                ret = true;
            }
            return ret;
        }
    }
}