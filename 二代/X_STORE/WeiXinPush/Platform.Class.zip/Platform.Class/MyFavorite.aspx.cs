﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Homory.Model;

public partial class MyFavorite :BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageInit();
        }
    }

    protected List<C_Adjunct> GetA(Guid id, int num)
    {
        return db.C_Adjunct.Where(o => o.ContentId == id && o.Type == num).ToList();
    }

    protected string GetFileName(string url)
    {

        if (string.Empty.Equals(url))
        {
            return string.Empty;
        }

        var url_list = url.Split('/');

        return url_list[url_list.Length - 1].Substring(37).ToString();

    }

    /// <summary>
    /// 页面初始化
    /// </summary>
    //private void PageInit(int type = 1)
    //{

    //    var user_id = Guid.Parse(Session["user_id"].ToString());

    //    var class_id = Guid.Parse(Session["class_id"].ToString());

    //    //var course_id = Guid.Parse(Session["course_id"].ToString());

    //var content_list = model.FindMyCollectContentByUserId(user_id, type);

    //    this.content_R.DataSource = content_list;

    //    this.content_R.DataBind();



    //}

    private void PageInit(int type = 1) {

        var UserId = Guid.Parse(Session["user_id"].ToString());

        var ContentList = model.FindMyCollectContentByUserId(UserId, type);

        var YearList = ContentList.Select(o => new {Time = o.DateTime.Year,Type = type}).Distinct().ToList();

        this.YearRepeater.DataSource = YearList;

        this.YearRepeater.DataBind();

        this.BodyRepeater.DataSource = YearList;

        this.BodyRepeater.DataBind();


    }
    protected List<View_ContentCollect> FindYearContent(string Year,string Type) {

        var ContentList = model.FindMyCollectContentByUserId(CurrentUser.Id, Convert.ToInt32(Type));

        return ContentList.Where(o=>o.DateTime.Year.ToString() == Year).ToList();
    }

    protected string GetTime(string time) {

        DateTime dt = Convert.ToDateTime(time);

        return dt.Hour.ToString() + dt.Minute.ToString() + dt.Second.ToString();

    
    }

    protected string GetDate(string time) {

        DateTime dt = Convert.ToDateTime(time);

        return dt.Date.ToString();

    
    }

    protected int get_collect_count(string content_id_str)
    {

        Guid content_id = Guid.Parse(content_id_str);

        Guid user_id = Guid.Parse(Session["user_id"].ToString());

        var cc_list = db.C_Collect.Where(o => o.isCollect == true && o.ContentId == content_id).ToList();

        int collect_count = 0;

        if (cc_list != null)
        {
            collect_count = cc_list.Count();
        }

        return collect_count;

    }

   
    protected string get_collect(string content_id_str)
    {

        Guid content_id = Guid.Parse(content_id_str);

        Guid user_id = Guid.Parse(Session["user_id"].ToString());

        C_Collect cc = db.C_Collect.SingleOrDefault(o => o.UserId == user_id && o.ContentId == content_id);

        bool collect_b = false;

        if (cc != null)
        {
            collect_b = cc.isCollect;
        }
        return collect_b ? "取消收藏" : "收藏";
    }
    protected void favorite_panel_AjaxRequest(object sender, Telerik.Web.UI.AjaxRequestEventArgs e)
    {

        var type = Convert.ToInt32(e.Argument.ToString());

        PageInit(type);
    }

    protected void BodyRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {

        Repeater ContentRepeater = (Repeater)e.Item.FindControl("ContentRepeater");

        dynamic data = e.Item.DataItem;

        int Type = int.Parse(data.Type.ToString());

        var Year = data.Time.ToString();

        var ContentList = model.FindMyCollectContentByUserId(CurrentUser.Id, Type);

        ContentRepeater.DataSource = ContentList.Where(o => o.DateTime.Year.ToString() == Year).ToList();

        ContentRepeater.DataBind();

        var idList = ContentList.Select(o => o.Id.ToString("N")).ToList();

        var json = Newtonsoft.Json.JsonConvert.SerializeObject(idList);

        favorite_panel.ResponseScripts.Add("goFancyBoxEx('"+ json +"');");

    }
}