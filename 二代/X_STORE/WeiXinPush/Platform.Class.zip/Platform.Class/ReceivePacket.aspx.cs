﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EntityFramework.Extensions;
using System.Data;
using Homory.Model;

public partial class ReceivePacket : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PageInit();
    }
    protected void PageInit(int index = 1,int type = 1)
    {

        var code = HttpContext.Current.Request.QueryString["code"];

        if (code != null)
        {
            var url = weixin_url + "ReceivePacket.aspx";

            VisitCheck(code, url);
        }

        var rp = db.C_call.Where(o => o.ReceiverID == UserId && o.State < State.审核).OrderBy(o => o.isRead).OrderByDescending(o => o.Datetime).ToList().GroupBy(o => o.TopId).ToList();

        List<C_call> packet_source = new List<C_call>();

        foreach (var item in rp)
        {
            packet_source.Add(item.OrderByDescending(o => o.Datetime).FirstOrDefault());
        }
     
        var receiveDt = packet_source.Select
                                            (
                                            s =>
                                            new
                                            {
                                                ReceiveName = s.User.RealName,
                                                Id = s.Id,
                                                TopMessage = s.C_call2.Message,
                                                Message = s.ParentId == null ? s.Message : "回复:" + s.Message,
                                                Datetime = s.Datetime,
                                                ParentId = s.ParentId,
                                                isRead = s.isRead
                                            }).ToList();
        this.paging_div.Visible = receiveDt.Count() > 0 ? true : false;

        var pageSize = 10;

        this.page_repeater.DataSource = pagingInit(index, receiveDt.Count(), pageSize);

        this.page_repeater.DataBind();

        this.receive_packet_P.DataSource = receiveDt.Skip((index - 1) * pageSize).Take(pageSize).ToList();

        this.receive_packet_P.DataBind();

        this.UserIdTB.Text = UserId.ToString();

    }
    protected DataTable pagingInit(int index, int total, int page_size)
    {

        var page_index = 0;

        var total_page = 0;

        var show_page_count = 0;

        DataTable page_dt = new DataTable();

        total_page = (total + page_size - 1) / page_size;

        show_page_count = ((total_page + page_size - 1) / page_size == (index + page_size - 1) / page_size) ? total_page + 1 : ((index + page_size - 1) / page_size) * page_size + 1;

        page_index = (index / page_size + index % page_size) > 1 ? (((index + page_size - 1) / page_size - 1) * page_size + 1) : 1;

        page_dt.Columns.Add("class", typeof(string));
        page_dt.Columns.Add("index", typeof(int));
        page_dt.Columns.Add("info", typeof(string));
        page_dt.Columns.Add("click", typeof(string));

        DataRow dr = page_dt.NewRow();

        dr["class"] = "";
        dr["info"] = "&laquo;";
        dr["index"] = (index / page_size) <= 1 ? 1 : (index / page_size - 1) * page_size + 1;
        dr["click"] = "left_ten_click(this)";

        page_dt.Rows.Add(dr);

        dr = page_dt.NewRow();

        dr["class"] = "";
        dr["info"] = "&lsaquo;";
        dr["index"] = (index + page_size - 1) / page_size <= 1 ? 1 : index - 1;
        dr["click"] = "page_click(this)";

        page_dt.Rows.Add(dr);

        for (int i = page_index; i < show_page_count; i++)
        {
            //如果当前页为点击页，泽将class设置为active
            dr = page_dt.NewRow();

            if (i == index)
            {

                dr["class"] = "active";

            }
            else
            {

                dr["class"] = "";

            }

            dr["info"] = i.ToString();
            dr["index"] = i;
            dr["click"] = "page_click(this)";

            page_dt.Rows.Add(dr);

        }

        dr = page_dt.NewRow();

        dr["class"] = "";
        dr["info"] = "&rsaquo;";
        dr["index"] = index == total_page ? index : (index + 1);
        dr["click"] = "page_click(this)";

        page_dt.Rows.Add(dr);

        dr = page_dt.NewRow();

        dr["class"] = "";
        dr["info"] = "&raquo;";
        dr["index"] = (index + page_size) > total_page ? (index / page_size) * page_size + 1 : (index / page_size + 1) * page_size + 1;
        dr["click"] = "right_ten_click(this)";

        page_dt.Rows.Add(dr);

        return page_dt;

    }
    protected string IsRead(bool isRead) {
        switch (isRead)
	    {
            case false:return "img/hh.jpg";
            case true: return "img/hx.jpg";
            default: return "img/hh.jpg";
	    }
    }
    protected void packet_P_AjaxRequest(object sender, Telerik.Web.UI.AjaxRequestEventArgs e)
    {
 
        string[] data = e.Argument.ToString().Split('|');
        if (string.Empty.Equals(e.Argument.ToString()))
        {
            PageInit();
        }
        else
        {
            PageInit(Convert.ToInt32(data[0]), Convert.ToInt32(data[1]));
        }
       
    }
    protected void show_message_AjaxRequest(object sender, Telerik.Web.UI.AjaxRequestEventArgs e)
    {

        Guid packet_id = Guid.Parse(e.Argument.ToString());

        Guid Top_id = (Guid)db.C_call.SingleOrDefault(o => o.Id == packet_id).TopId;

        Guid user_id = Guid.Parse(this.Session["user_id"].ToString());

        db.C_call.Where(o => o.TopId == Top_id && o.ReceiverID == user_id).Update(x => new C_call
            { 
               isRead =true
            });

        db.SaveChanges();

        this.message_RTV.DataSource = db.C_call.Where(o => o.State < State.审核 && o.TopId == Top_id).ToList().OrderBy(o => o.Datetime).Select
         (
             o => new

                 {
                     ParentId = o.ParentId,

                     Id = o.Id,

                     UserName = o.User.RealName,

                     Message = o.Message,

                     Time = o.Datetime
                 }

                 

         );

        this.message_RTV.DataBind();

        this.message_RTV.ExpandAllNodes();

        var userList = Session["user_id"].ToString() + "|";

        packet_P.ResponseScripts.Add("PushMessageOther('" + userList + "')");

    }
}