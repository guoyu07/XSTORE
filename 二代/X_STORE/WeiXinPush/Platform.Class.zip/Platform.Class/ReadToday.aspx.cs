﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Homory.Model;

public partial class ReadToday : BasePage
{
    Model model = new Model();

    protected void Page_Load(object sender, EventArgs e)
    {
        PageInit();
    }

    protected List<C_Adjunct> GetA(Guid id, int num)
    {
        return db.C_Adjunct.Where(o => o.ContentId == id && o.Type == num).ToList();
    }

    protected string GetFileName(string url)
    {

        if (string.Empty.Equals(url))
        {
            return string.Empty;
        }

        var url_list = url.Split('/');

        return url_list[url_list.Length - 1].Substring(37).ToString();

    }

    /// <summary>
    /// 页面初始化
    /// </summary>
    private void PageInit(string text = "")
    {

        var class_id = Guid.Parse(Session["class_id"].ToString());

        var content_list = model.FindContentByClassId(class_id,text);

        this.content_R.DataSource = content_list;

        this.content_R.DataBind();

    }
 }