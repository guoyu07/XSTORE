﻿using System;
using System.IO;
using System.Linq;
using Homory.Model;
using Telerik.Web.UI;
using Resource = Homory.Model.Resource;
using ResourceType = Homory.Model.ResourceType;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections.Generic;
using NReco.VideoConverter;

namespace Popup
{
    public partial class PopupPublishAttachment : HomoryPage
	{
		protected void Page_Load(object sender, EventArgs e)
		{
            if (!IsPostBack)
            {
                SessionEmpty();
            }
        }

        private string get_type(int type) {

            switch (type)
            {
                case 1: return "图片";

                case 2: return "视频";

                case 3: return "附件";

                default: break;
            }

            return "";

        }

        protected void SessionEmpty() {

            this.Session["suo_picture_src"] = string.Empty;

            this.Session["picture_src"] = string.Empty;

            this.Session["X"] = string.Empty;

            this.Session["Type"] = string.Empty;

            this.Session["movie_src"] = string.Empty;

            this.Session["movie_src"] = string.Empty;

            this.Session["suo_movie_src"] = string.Empty;

            this.Session["adjunct_src"] = string.Empty;

            this.Session["adjunct_name"] = string.Empty;
           

        }

		protected void publish_attachment_upload_OnFileUploaded(object sender, FileUploadedEventArgs e)
		{

            

            int type = Convert.ToInt32(Request.QueryString["Type"].ToString());

            int X = Request.QueryString["X"] == null ? 0 : Convert.ToInt32(Request.QueryString["X"]);

			var file = e.File;

            var name = string.Format("../Common/班级/{2}/{1}_{0}", file.FileName, HomoryContext.Value.GetId(), get_type(type));

			file.SaveAs(Server.MapPath(name), true);

            var suo_name = string.Format("../Common/班级/{2}/{1}_{0}", file.FileName.Replace(file.GetExtension().Replace(".",""),"jpg"), HomoryContext.Value.GetId(),get_type(type));

            this.Session["Type"] = type;

            var source_path = Server.MapPath(name);

            var suo_source_path = Server.MapPath(suo_name);

            switch (type)
            {
                case 1:
                   
                    MakeThumb(source_path, suo_source_path, 90, 120, "H");

                    this.Session["suo_picture_src"] += suo_name + "|";

                    this.Session["picture_src"] += name + "|";

                    this.Session["X"] = X;

                    break;
                case 2:
                    var convert_source_src = name.Replace(source_path.Split('.')[source_path.Split('.').Length - 1], "flv");

                    var convert_source_path = Server.MapPath(convert_source_src);

                    var suo_temp_name = string.Format("../Common/班级/{2}/{1}_{0}", file.FileName.Replace(file.GetExtension().Replace(".", ""), "jpg"), HomoryContext.Value.GetId(), get_type(type));

                    switch (file.GetExtension().Replace(".","").ToLower())
	                {
                        case "avi":
                        case "mpg":
                        case "mpeg":
                        case "flv":
                        case "mp4":
                        case "rm":
                        case "rmvb":
                        case "wmv":
                            NReco.VideoConverter.FFMpegConverter c = new NReco.VideoConverter.FFMpegConverter();

                            c.GetVideoThumbnail(source_path, Server.MapPath(suo_temp_name), 2F);

                            MakeThumb(Server.MapPath(suo_temp_name), suo_source_path, 50, 80, "H");

                            if (!source_path.EndsWith("flv"))
                            {
                                c.ConvertMedia(source_path, convert_source_path, NReco.VideoConverter.Format.flv);
                            }
                            break;
                        default: break;
	                }

                    this.Session["movie_src"] = convert_source_src + "|";

                    this.Session["suo_movie_src"] = suo_name + "|";

                    break;
                case 3:

                    this.Session["adjunct_src"] += name + "|";

                    this.Session["adjunct_name"] += file.FileName + "|";

                    break;
                default:
                    break;
            }
		}

		protected void publish_attachment_commit_OnServerClick(object sender, EventArgs e)
		{
            string json_result = string.Empty;

            switch (Convert.ToInt32(this.Session["Type"].ToString()))
            {
                case 1:
                    int X = Convert.ToInt32(this.Session["X"].ToString());
                    switch (X)
	                {
                        case 0:
                            json_result = "{\"Type\":\"" + this.Session["Type"].ToString() + "\",\"suo_picture\":\"" + this.Session["suo_picture_src"].ToString().TrimEnd('|') + "\",\"picture\":\"" + this.Session["picture_src"].ToString().TrimEnd('|') + "\"}";    
                            break;
                        case 1: 
                        case 2:
                            json_result = "{\"X\":\"" + X + "\",\"Type\":\"" + this.Session["Type"].ToString() + "\",\"suo_picture\":\"" + this.Session["suo_picture_src"].ToString().TrimEnd('|') + "\",\"picture\":\"" + this.Session["picture_src"].ToString().TrimEnd('|') + "\"}";    
                            break;
                        default:
                            break;
	                }
                    
                    break;
                case 2:
                    json_result = "{\"Type\":\"" + this.Session["Type"].ToString() + "\",\"movie\":\"" + this.Session["movie_src"].ToString().TrimEnd('|') + "\",\"suo_movie\":\"" + this.Session["suo_movie_src"].ToString().TrimEnd('|') + "\"}";
                    break;
                case 3:
                    json_result = "{\"Type\":\"" + this.Session["Type"].ToString() + "\",\"adjunct_src\":\"" + this.Session["adjunct_src"].ToString().TrimEnd('|') + "\",\"adjunct_name\":\"" + this.Session["adjunct_name"].ToString().TrimEnd('|') + "\"}";
                    break;
                default:
                    break;
            }
            
            popup_publish_attachment_panel.ResponseScripts.Add("RadCloseRebind('" + json_result + "');");

            SessionEmpty();
		}

        public static void MakeThumb(string originalImagePath, string thumNailPath, int width, int height, string model)
        {
            System.Drawing.Image originalImage = System.Drawing.Image.FromFile(originalImagePath);

            int thumWidth = width;      //缩略图的宽度

            int thumHeight = height;    //缩略图的高度

            int x = 0;

            int y = 0;

            int originalWidth = originalImage.Width;    //原始图片的宽度

            int originalHeight = originalImage.Height;  //原始图片的高度

            switch (model)
            {
                case "HW":      //指定高宽缩放,可能变形
                    break;
                case "W":       //指定宽度,高度按照比例缩放
                    thumHeight = originalImage.Height * width / originalImage.Width;
                    break;
                case "H":       //指定高度,宽度按照等比例缩放
                    thumWidth = originalImage.Width * height / originalImage.Height;
                    break;
                case "Cut":
                    if ((double)originalImage.Width / (double)originalImage.Height > (double)thumWidth / (double)thumHeight)
                    {
                        originalHeight = originalImage.Height;
                        originalWidth = originalImage.Height * thumWidth / thumHeight;
                        y = 0;
                        x = (originalImage.Width - originalWidth) / 2;
                    }
                    else
                    {
                        originalWidth = originalImage.Width;
                        originalHeight = originalWidth * height / thumWidth;
                        x = 0;
                        y = (originalImage.Height - originalHeight) / 2;
                    }
                    break;
                default:
                    break;
            }

            //新建一个bmp图片
            System.Drawing.Image bitmap = new System.Drawing.Bitmap(thumWidth, thumHeight);

            //新建一个画板
            System.Drawing.Graphics graphic = System.Drawing.Graphics.FromImage(bitmap);

            //设置高质量查值法
            graphic.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;

            //设置高质量，低速度呈现平滑程度
            graphic.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

            //清空画布并以透明背景色填充
            graphic.Clear(System.Drawing.Color.Transparent);

            //在指定位置并且按指定大小绘制原图片的指定部分
            graphic.DrawImage(originalImage, new System.Drawing.Rectangle(0, 0, thumWidth, thumHeight), new System.Drawing.Rectangle(x, y, originalWidth, originalHeight), System.Drawing.GraphicsUnit.Pixel);

            try
            {
                bitmap.Save(thumNailPath, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                originalImage.Dispose();
                bitmap.Dispose();
                graphic.Dispose();
            }
        }
   
	}
}
