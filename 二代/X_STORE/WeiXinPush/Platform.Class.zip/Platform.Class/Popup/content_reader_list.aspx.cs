﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Popup_content_reader_list : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void content_reader_RG_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
    {
        Guid content_id = Guid.Parse(Request.QueryString["content_id"].ToString());
        this.content_reader_RG.DataSource = db.C_Collect.Where(o => o.ContentId == content_id).ToList().Join(db.User, o => o.UserId, o => o.Id, (c, u) => new
        {
            Name = u.DisplayName,
            Time = c.ReadTime
        }).ToList();
    }
}