﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using Homory.Model;

public partial class Popup_content_assistant : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            PageInit();
        }

    }

    public string CutString(string text, int? maxLength, string suffix = "")
    {
        if (string.IsNullOrWhiteSpace(text))
            return string.Empty;
        if (!maxLength.HasValue)
            maxLength = text.Length - 1;
        return text.Length > maxLength
            ? string.Format("{0}{1}", text.Substring(0, maxLength.Value), suffix)
            : text;
    }

    protected void PageInit(string Grade = "", string Catalog = "", string Content = "")
    {

        BindList(Grade, Catalog, Content);

        //绑定年级
        this.grade_RDD.DataSource = FindAges();

        this.grade_RDD.DataBind();

        this.grade_RDD.Items.Insert(0, new DropDownListItem("年级", Guid.Empty.ToString()));

        //this.grade_RDD.Items.Insert(0, new DropDownListItem("年级", Guid.Empty.ToString()));


        //绑定学科
        this.class_RDD.DataSource = db.Catalog.Where(o => o.Type == CatalogType.课程 && o.State < State.审核).OrderBy(o=>o.Ordinal).Select(o => new 
        {
            Id = o.Id,

            Name = o.Name
        
        }).ToList();

        this.class_RDD.DataBind();

        this.class_RDD.Items.Insert(0, new DropDownListItem("学科", Guid.Empty.ToString()));

    }
    public void BindList(string Grade = "", string Catalog = "", string Content = "")
    {
        Guid _Grade = Grade.Equals("") ? Guid.Empty : Guid.Parse(Grade);

        Guid _Catalog = Catalog.Equals("") ? Guid.Empty : Guid.Parse(Catalog);

        Func<View_ResourceAssistantInClass, bool> Exp = o => true;

        Exp += (o => o.State < 2);

        if (_Grade != Guid.Empty)
        {
            Exp += (o => o.GradeId == _Grade);
        }
        if (_Catalog != Guid.Empty)
        {
            Exp += (o => o.CourseId == _Catalog);
        }
        if (Content != string.Empty)
        {
            Exp += (o => o.Title.Contains(Content));
        }
        var resource_list = db.View_ResourceAssistantInClass.Where(Exp).OrderByDescending(o=>o.Time).ToList();

        this.content_assistant.DataSource = resource_list;

        this.content_assistant.DataBind();

        
    }
    protected void search_content_RSB_Search(object sender, SearchBoxEventArgs e)
    {
        string Grade = this.grade_RDD.SelectedValue;

        string Catalog = this.class_RDD.SelectedValue;

        string Content = this.search_content_RSB.Text;

        BindList(Grade, Catalog, Content);
    }
}