﻿using Homory.Model;
using System;
using System.Linq;
using System.Web;

public partial class CutPicture : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageInit();
        }
    }
    protected void PageInit() {


        var PictureUrl = Server.UrlDecode(Request.QueryString["PictureUrl"].ToString());

        var FileName = Server.UrlDecode(Request.QueryString["FileName"].ToString());


        this.CutPictureImg.Src = PictureUrl;

        this.imgSrc.Value = PictureUrl;

        this.ImgTitle.InnerText = FileName;

    }
}