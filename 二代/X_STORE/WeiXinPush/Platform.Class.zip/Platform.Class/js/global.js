﻿/// <reference path="jquery.js" />
function selectCurrentMenu(pageIndex, subIndex) {
    $(".sidebar-menu").children("li").each(function (index, element) {
        if (index == pageIndex) {
            $(element).addClass("active");
            $(element).children("ul").css("display","block");
            $(element).children("ul").children("li").each(function (s_index, s_element) {
                if (s_index == subIndex) {
                    $($(s_element).children("a")).css("color", "#E6E9ED");
                }
                else
                    $($(s_element).children("a")).css("color", "#AAB2BD");
            });
        }
        else
            $(element).removeClass("active");
    });
}
