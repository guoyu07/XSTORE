﻿//tip pop
function tip(val, successed) {
    mShowMessage(val, successed);
}
//new function to show message
var foTimeoutID = "";
var m_last_div_id = "";
function mShowMessage(msg, flag) {
    if (msg == "undefined" || msg == null || $.trim(msg) == "") { return; }
    if (flag == "undefined" || flag == null) {
        flag = false;
    }
    if (foTimeoutID != "" && $(m_last_div_id).length > 0) {
        $(m_last_div_id).hide();
    }
    foTimeoutID = window.clearTimeout(foTimeoutID);
    var msg_id = "";
    var div_id = "";
    var close_id = "";
    if (flag) {
        div_id = "#yj-notice";
        msg_id = "#mNoticeMsgContainerSpan";
        close_id = "#mNotice_close";
        if ($("#yj-notice").length == 0) {
            $('<div id="yj-notice" class="yj-alert yj-notice" style="display:none;"><p><a id="mNotice_close" class="yj-closeFlash" href="javascript://">x</a><span id="mNoticeMsgContainerSpan"></span></p></div> ').appendTo("body");
        }
    } else {
        div_id = "#yj-error";
        msg_id = "#mErrorMsgContainerSpan";
        close_id = "#mError_close";
        if ($("#yj-error").length == 0) {
            $('<div id="yj-error" class="yj-alert yj-error" style="display:none;"><p><a id="mError_close" class="yj-closeFlash" href="javascript://">x</a><span id="mErrorMsgContainerSpan"></span></p></div>').appendTo("body");
        }
    }
    m_last_div_id = div_id;
    var _left = (document.documentElement.clientWidth - $(div_id).width()) / 2;
    var _top = (document.documentElement.clientHeight - $(div_id).height()) / 2;
    $(div_id).css("margin-left", _left).css("margin-top", 20);
    $(msg_id).html(msg);
    $(div_id).stop(true, true).fadeIn("slow");
    foTimeoutID = window.setTimeout(function () {
        $(div_id).fadeOut("slow");
        foTimeoutID = "";
    }, 2000);
    $(close_id).get(0).onclick = function () {
        window.clearTimeout(foTimeoutID);
        foTimeoutID = "";
        $(div_id).fadeOut("slow");
    };
}