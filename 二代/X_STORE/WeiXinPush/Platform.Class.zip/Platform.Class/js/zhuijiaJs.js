﻿$(window).scroll(function () {

    if ($(document).scrollTop() + $(window).height() >= $(document).height()) {

        var content_list_count = $(".content_repeater_class").length;

        if (!$(".content_repeater_class")) {

            content_list_count = 0;

        }

        var searchText = $find("<%= topMenu.Searcher.ClientID %>").get_text();

        rebindRepeater(searchText, content_list_count, 1);
    }
});