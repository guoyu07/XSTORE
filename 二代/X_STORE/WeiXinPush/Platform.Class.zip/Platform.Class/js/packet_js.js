﻿
        var timePeriod = 5000;
jQuery.fn.extend({
    slideRightShow: function () {
        return this.each(function () {
            $(this).show('slide', { direction: 'right' }, timePeriod);
        });
    },
    slideLeftHide: function () {
        return this.each(function () {
            $(this).hide('slide', { direction: 'left' }, timePeriod);
        });
    },
    slideRightHide: function () {
        return this.each(function () {
            $(this).hide('slide', { direction: 'right' }, timePeriod);
        });
    },
    slideLeftShow: function () {
        return this.each(function () {
            $(this).show('slide', { direction: 'left' }, timePeriod);
        });
    }
});

    $(document).ready(function () {

        $(".subject").on("click", function () {

            var event = $(this).parent().parent();

            var packet_id = event.find("input").attr("id");

            $.post(

                "Handler/find_packet_message_Handler.ashx",

                { packet_id: packet_id },

                function (result) {

                    var json_result = eval("(" + result + ")");

                    $("#send_person_L").html(json_result[0].sendName);

                    $("#send_message_L").html(json_result[0].message);

                    $("#packet_id_I").val(json_result[0].id);

                    event.find("#span_" + json_result[0].id + "").removeClass().addClass("favorite fa fa-star text-warning");

                    jQuery("#show_message_div").show('slow', 'swing');
                })

        });
        $(".packet_reply_class").on("click", function () {

            var packet_id = $("#packet_id_I").val();

            var reply_message = $("#reply_message_TA").val();

            $.post(

                'Handler/reply_packet_message_Handler.ashx',

                { packet_id: packet_id, reply_message: reply_message },

                function (result) {



                })

        })
        $("#packet_delete_B").on("click", function () {
                   
            var box_list = $("#packet_list_div").find("input[type='checkbox']");

            alert(box_list.length);

            var packet_id_list = "";

            box_list.each(function () {

                alert($(this).attr("checked"));

                if ($(this).attr("checked") == "checked") {

                    packet_id_list += $(this).attr("id") + "|";
                } 

            });


            $.post(

                'Handler/update_packet_message_Handler.ashx',

                { packet_id_list: packet_id_list },

                function (result) {

                    if (result == "true") {

                        var box_list = $("#packet_list_div").find("input[type='checkbox']");

                        for (var i = 0; i < box_list.length; i++) {

                            if (box_list[i].attr("checked")) {

                                box_list[i].parent().parent().remove();

                            }
                        }

                    }

                        
                })

        })
    });

function hide() {
    jQuery("#show_message_div").hide('slow', 'swing');
}
