﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClassWork : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var code = HttpContext.Current.Request.QueryString["code"];

        if (code != null)
        {
            var url = weixin_url + "ClassWork.aspx";

            VisitCheck(code, url);
        }
    }
    protected void Page_PreRender(object sender, EventArgs e)
    {
        try
        {
            var ClassId = Guid.Parse(this.Session["class_id"].ToString());

            this.AlbumRepeater.DataSource = db.View_AlbumList.Where(o => o.ClassId == ClassId).ToList().OrderBy(o => o.CreateTime).ToList();

            this.AlbumRepeater.DataBind();
        }
        catch (Exception)
        {

            var url = string.Format("{0}/SignOff?SsoRedirect={1}", base_url, Server.UrlEncode(string.Format("{0}/SignOn", base_url)));

            Response.Redirect(url, false);
        }
    }
}