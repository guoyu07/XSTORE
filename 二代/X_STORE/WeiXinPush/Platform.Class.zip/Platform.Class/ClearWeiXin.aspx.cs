﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClearWeiXin : BasePage
{
    WeiXin wx = new WeiXin();

    private string GlobalOpenId;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            var code = HttpContext.Current.Request.QueryString["code"];

            GlobalOpenId = wx.GetOpenId(code);

            var userOpen = db.UserOpen.Where(o => o.OpenId == GlobalOpenId).ToList();

             foreach (var item in userOpen)
             {
                 db.UserOpen.Remove(item);

             }

             db.SaveChanges();

             wxmessage wxmessage = new wxmessage();

             wxmessage.Content = "";

             wxmessage.EventName = "";

             wxmessage.FromUserName = "";

             wxmessage.MsgType = "text";

             wxmessage.ToUserName = GlobalOpenId;

             var res = wx.sendTextMessage(wxmessage, "你已成功解除绑定");

             HttpContext.Current.Response.Write(res);  

             //Response.End();    
        }
    }
}