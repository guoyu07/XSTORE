﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WeiXinBinder : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {

        var code = HttpContext.Current.Request.QueryString["code"];

        if (code != null)
        {
            var url = weixin_url + "WeiXinBinder.aspx";

            VisitCheck(code, url);

        }
        else
        {
            PageInit();
        }
    }

    protected void PageInit(){


        WeiXin wx = new WeiXin();

        var UserId = Guid.Parse(this.Session["user_id"].ToString());

        var OpenIdList = db.UserOpen.Where(o => o.UserId == UserId).ToList();

        var AccessToken = WeiXin.GetAccess_token().access_token;

        DataTable dt = new DataTable();

        dt.Columns.Add("HeadPic",Type.GetType("System.String"));

        dt.Columns.Add("NickName", Type.GetType("System.String"));

        dt.Columns.Add("DateTime", Type.GetType("System.String"));
       
        if (OpenIdList.Count() > 0)
        {
            foreach (var openId in OpenIdList)
            {

                DataRow dr = dt.NewRow();

                UserInfo ui = wx.GetUserInfoByOpenId(AccessToken, openId.OpenId.ToString());

                dr["HeadPic"] = ui.headimgurl;

                dr["NickName"] = ui.nickname;

                dr["DateTime"] = string.Format("{0:yyyy-MM-dd}",Convert.ToDateTime(openId.DateTime));;

                dt.Rows.Add(dr);

            }

            this.WeiXinRepeater.DataSource = dt;

            this.WeiXinRepeater.DataBind();
        }

      
    }
}