﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void ok_Click(object sender, EventArgs e)
    {

        label.Text = (panel.Controls.OfType<TextBox>().Select(o => o.Text).Aggregate<string, string, string>("", (o1, o2) => o1 += o2 + ",", o => o.Substring(0, o.Length - 1)));

        var array = label.Text.Split(new char[] { ',' });

        p.Controls.OfType<Label>().Select(o => o).ToList().ForEach(o =>
        {
            o.Text = array[int.Parse(o.ID.Replace("Label", "")) - 1];
        });

    }

}